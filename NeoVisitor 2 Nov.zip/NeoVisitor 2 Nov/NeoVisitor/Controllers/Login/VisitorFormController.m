#import "VisitorFormController.h"
#import "AppDelegate.h"
#import "ErrorMessages.h"
#import "AppKeys.h"
#import "Constant.h"
#import "WebServiceHandler.h"
#import "ErrorMessages.h"
#import "EventsListTableViewController.h"
#import "UserListTableViewController.h"
#import <AudioToolbox/AudioToolbox.h>
#import "UIImage+Scaling.h"
#import "DBOperations.h"
#import "CommonMethods.h"
#import "CardInfoModel.h"
#import "QRViewController.h"
#define MENU_POPOVER_FRAME  CGRectMake(8, 64, 140, 130)

@interface VisitorFormController ()<EventListingDelegate,UserListingDelegate,UIActionSheetDelegate,ZBarReaderDelegate>
{
    BOOL isBackImage;
    NSString *tempCommentString;
}
@property(nonatomic,strong)NSDictionary *selectedEventData;
@property(nonatomic,strong)NSDictionary *selectedonBehalfData;

@property(nonatomic,assign)float rating;
@end

@implementation VisitorFormController
-(void)viewDidLoad
{
    self.txtComment.layer.borderWidth=0.8;
    self.txtComment.layer.borderColor = [UIColor colorWithRed:0.9020 green:0.9020 blue:0.9020 alpha:1].CGColor;
    self.txtComment.layer.cornerRadius=7;
    self.txtComment.delegate=(id)self;
    tempCommentString =@"Comments";
    self.txtComment.textColor = [UIColor colorWithRed:0.7804 green:0.7804 blue:0.7804 alpha:1];
    self.txtComment.text = tempCommentString;
    DoneCancelNumberPadToolbar *toolbar = [[DoneCancelNumberPadToolbar alloc] initWithTextField:self.txtComment];
    toolbar.delegate = (id)self;
    self.txtComment.inputAccessoryView = toolbar;
    self.rateView.rating = 0;
    self.rateView.editable = YES;
    self.rateView.maxRating = 5;
    self.rateView.delegate = (id)self;
    self.rateView.notSelectedImage = [UIImage imageNamed:@"greyStar"];
    self.rateView.fullSelectedImage = [UIImage imageNamed:@"yellowStar"];
    self.menuItems = [NSArray arrayWithObjects:@"Scan QR", @"View QR Scan",@"Logout",nil];
    
    [self clearFields];
    
    
    UIButton *aButton = [UIButton buttonWithType:UIButtonTypeCustom];
    aButton.frame = CGRectMake(0.0, 0.0, 65, 25);
    [aButton setTitle:@"Sync" forState:UIControlStateNormal];
    [aButton showsTouchWhenHighlighted];
    [aButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [aButton setBackgroundColor:[UIColor clearColor]];
    UIBarButtonItem *aBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:aButton];
    [aButton addTarget:self action:@selector(syncAllCard) forControlEvents:UIControlEventTouchUpInside];
    [self.navigationItem setRightBarButtonItem:aBarButtonItem];
    
    UIButton *rButton = [UIButton buttonWithType:UIButtonTypeCustom];
    rButton.frame = CGRectMake(10.0, 0.0, 65,25);
    [rButton setTitle:@"Logout" forState:UIControlStateNormal];
    [rButton showsTouchWhenHighlighted];
    [rButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [rButton setBackgroundColor:[UIColor clearColor]];
    UIBarButtonItem *rBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:rButton];
    [rButton addTarget:self action:@selector(logout) forControlEvents:UIControlEventTouchUpInside];
    [self.navigationItem setLeftBarButtonItem:rBarButtonItem];
    
    
    _btnSave.layer.cornerRadius = 10;
    
    [self setupLeftView:self.txtEname];
    [self setupLeftView:self.txtVname];
    [self setupRightView:self.txtBehalf];
    [self setupRightView:self.txtEname];
    [self setupLeftView:self.txtVisitorEmail];
    [self setupLeftView:self.txtVisitorPhoneNumber];
    
    self.txtVname.textColor = [UIColor blackColor];
    self.txtEname.textColor = [UIColor blackColor];
    
    
    UITapGestureRecognizer *gesture=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(frontImageSelected:)];
    [self.frontImageView addGestureRecognizer:gesture];
    self.frontImageView.userInteractionEnabled=YES;
    
    
    UITapGestureRecognizer *gesture1=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(BackImageSelected:)];
    [self.backImagView addGestureRecognizer:gesture1];
    self.backImagView.userInteractionEnabled=YES;
    
    [USER_DEFAULTS synchronize];
    if(![USER_DEFAULTS objectForKey:rem_user_id])
    {
        [USER_DEFAULTS setObject:[[USER_DEFAULTS objectForKey:rem_user_Info]objectForKey:rem_user_id]  forKey:rem_user_id];
        [USER_DEFAULTS setObject:[[USER_DEFAULTS objectForKey:rem_user_Info]objectForKey:rem_user_email]  forKey:rem_user_email];
        
        [USER_DEFAULTS synchronize];
    }
    else{
    }
    
    self.title=@"";
    
    NSArray *subStrings = [[[USER_DEFAULTS objectForKey:rem_user_Info]objectForKey:rem_user_email] componentsSeparatedByString:@"@"];
    if([subStrings count]>0)
    {
        NSString *firstString = [subStrings objectAtIndex:0];
        
        
        UILabel *lblUserName=[[UILabel alloc]initWithFrame:CGRectMake(0, 8, 200, 30)];
        lblUserName.text=[firstString capitalizedString];
        lblUserName.textColor=[UIColor whiteColor];
        lblUserName.backgroundColor=[UIColor clearColor];
        lblUserName.font=[UIFont boldSystemFontOfSize:17.0f];
        lblUserName.textAlignment=NSTextAlignmentCenter;
        self.navigationItem.titleView=lblUserName;
    }
    
    NSString *strUserName=[USER_DEFAULTS objectForKey:rem_user_email];
    self.txtBehalf.text=strUserName;
    
    if([[AppDelegate getInstance].arrAppEvents count]>0)
    {
        [self selectedEventData:[[AppDelegate getInstance].arrAppEvents firstObject]];
    }
}
-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:YES];
    self.mainScroll.scrollEnabled=YES;
}
-(void)viewDidLayoutSubviews
{
    self.mainScroll.contentSize=CGSizeMake(self.mainScroll.frame.size.width, 800);
}
-(void)setupLeftView:(UITextField *)txtField
{
    UIView *leftView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 5, 20)];
    leftView.backgroundColor=[UIColor clearColor];
    txtField.leftView = leftView;
    txtField.leftViewMode = UITextFieldViewModeAlways;
}
-(void)setupRightView:(UITextField *)txtField
{
    UIView *rightView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 20, 20)];
    UIImageView *imageView=[[UIImageView alloc]initWithFrame:rightView.frame];
    UIImage *image=[UIImage imageNamed:@"arrow"];
    imageView.image=image;
    imageView.contentMode=UIViewContentModeScaleAspectFit;
    [rightView addSubview:imageView];
    rightView.backgroundColor=[UIColor clearColor];
    txtField.rightView = rightView;
    txtField.rightViewMode = UITextFieldViewModeAlways;
    rightView.userInteractionEnabled=NO;
    imageView.userInteractionEnabled=NO;
}
-(void)viewWillAppear:(BOOL)animated
{
    self.navigationController.navigationBarHidden=NO;
    
    CGRect rect=[UIScreen mainScreen].bounds;
    float height=(rect.size.width-40)/2;
    self.fImageHeight.constant=height;
    self.bImageHeight.constant=height;
    
    
    self.mainScroll.contentSize=CGSizeMake(self.mainScroll.frame.size.width, 800);
    self.mainScroll.contentOffset=CGPointZero;
}
-(void)logout
{
    [USER_DEFAULTS removeObjectForKey:rem_user_id];
    [USER_DEFAULTS removeObjectForKey:rem_user_email];
    [USER_DEFAULTS removeObjectForKey:rem_user_Info];
    [USER_DEFAULTS synchronize];
    [self.navigationController popViewControllerAnimated:YES];
    
}
- (void)syncAllCard
{
    if(![[AppDelegate getInstance]CheckNetWorkConnection])
    {
        [[AppDelegate getInstance]PlayProgressHudAsPerType:msg_Internet_Connection View:nil];
        return;
    }
    [[AppDelegate  getInstance]showHud:nil Title:@"Fetching UnSynced Data"];
    NSMutableArray *arrData=[DBOperations getUnSyncCard:nil];
    if([arrData count]==0)
    {
        [[AppDelegate getInstance]PlayProgressHudAsPerType:msg_NO_Data View:nil];
        [[AppDelegate    getInstance]closeHud];
        return;
    }
    [[AppDelegate    getInstance]closeHud];
    
    [[WebServiceHandler sharedInstance]SyncCardListingDataFromServerUsingQueue:^(id response, NSError *error)
     {
         NSNumber *unSyncedCard=[DBOperations getTotalUnSyncCard];
         NSInteger SyncCount=[arrData count]-[unSyncedCard integerValue];
         [[AppDelegate getInstance]PlayProgressHudAsPerType:[NSString stringWithFormat:@"Successfully Synced %lu Entries", (unsigned long)SyncCount] View:nil];
     } ArrRequest:arrData];
}
#pragma mark -
#pragma mark UITextField delegates -
-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if([textField isEqual:self.txtBehalf])
    {
        UserListTableViewController *userObj=[self.storyboard instantiateViewControllerWithIdentifier:@"UserListTableViewController"];
        userObj.userDelegate=self;
        [self.navigationController pushViewController:userObj animated:YES];
        return NO;
    }
    return YES;
}
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    [self setTextViewValue];
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
- (void)textViewDidBeginEditing:(UITextView *)textView
{
    if([self.txtComment.text isEqualToString:@"Comments"])
    {
        self.txtComment.text = @"";
        tempCommentString=@"";
        self.txtComment.textColor = [UIColor blackColor];
        
    }
    tempCommentString = self.txtComment.text;
}
- (void)textViewDidEndEditing:(UITextView *)textView
{
    tempCommentString = self.txtComment.text;
    [self setTextViewValue];
}
-(void)textFieldDidEndEditing:(UITextField *)textField
{
    [self setTextViewValue];
}
#pragma  mark DoneCancelNumberPadToolbar delegate methods
-(void)doneCancelNumberPadToolbarDelegate:(DoneCancelNumberPadToolbar *)controller didClickDone:(id)textField
{
    tempCommentString = self.txtComment.text;
    
    [self setTextViewValue];
}
-(void)doneCancelNumberPadToolbarDelegate:(DoneCancelNumberPadToolbar *)controller didClickCancel:(id)textField
{
    tempCommentString = self.txtComment.text;
    
    [self setTextViewValue];
}
-(void)setTextViewValue
{
    tempCommentString=[tempCommentString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if([tempCommentString length]==0)
    {
        self.txtComment.textColor = [UIColor colorWithRed:0.7804 green:0.7804 blue:0.7804 alpha:1];
        self.txtComment.text = @"Comments";
    }
    else
    {
        
        self.txtComment.text = tempCommentString;
        self.txtComment.textColor = [UIColor blackColor];
    }
}

- (IBAction)frontImageSelected:(id)sender
{
    isBackImage=NO;
    [self captureImage];
    
}
- (IBAction)BackImageSelected:(id)sender
{
    isBackImage=YES;
    
    [self captureImage];
}
-(void)captureImage
{
    [self.view endEditing:YES];
    UIActionSheet *actionSheet = [[UIActionSheet alloc]
                                  initWithTitle:@"Pick Source"
                                  delegate:self
                                  cancelButtonTitle:@"Cancel"
                                  destructiveButtonTitle:nil
                                  otherButtonTitles:@"Camera",@"Gallery", nil];
    actionSheet.tag=1;
    [actionSheet showInView:self.view];
}
#pragma mark -
#pragma mark Camera pickerView delegates -

- (void)imagePickerController:(UIImagePickerController *)picker1 didFinishPickingMediaWithInfo:(NSDictionary *)info {
    if([info objectForKey: ZBarReaderControllerResults])
    {
        NSArray *items=[[NSArray alloc]init];
        id<NSFastEnumeration> results =
        [info objectForKey: ZBarReaderControllerResults];
        ZBarSymbol *symbol = nil;
        for(symbol in results)
        {
            items = [symbol.data componentsSeparatedByString:@"\n"];
            
            
        }
        [self dismissViewControllerAnimated:YES  completion:^{
            
            QRViewController *QRvc=[self.storyboard instantiateViewControllerWithIdentifier:@"QRViewController"];
            QRvc.QRVcardData=items;
            [self.navigationController pushViewController:QRvc animated:YES];
        }];
        return;
    }
    UIImage * imageToSave;
    UIImage * editedImage = (UIImage *) [info objectForKey: UIImagePickerControllerEditedImage];
    UIImage *originalImage = (UIImage *) [info objectForKey: UIImagePickerControllerOriginalImage];
    if (editedImage)
    {
        imageToSave = editedImage;
    }
    else
    {
        imageToSave = originalImage;
    }
    UIImage *bigImage=[imageToSave imageByScalingAndCroppingForSize:CGSizeMake(500, 500)];
    if(!isBackImage)
    {
        fImage=bigImage;
        self.frontImageView.image=fImage;
    }
    else
    {
        bImage=bigImage;
        self.backImagView.image=bImage;
    }
    [picker1 dismissViewControllerAnimated:YES completion:NULL];
}
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker1 {
    
    if([self.txtComment.text isEqualToString:@""])
    {
        self.txtComment.textColor = [UIColor colorWithRed:0.7804 green:0.7804 blue:0.7804 alpha:1];
        self.txtComment.text = @"Comments";
    }
    [picker1 dismissViewControllerAnimated:YES completion:NULL];
}
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex!=2)
    {
        picker = [[UIImagePickerController alloc] init];
        picker.delegate=(id)self;
        picker.allowsEditing=true;
        if  (buttonIndex == 0)
        {
            if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
            {
                [picker setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
            }
            else
            {
                picker.sourceType = UIImagePickerControllerSourceTypeCamera;
                
            }
        }
        else if (buttonIndex == 1)
        {
            [picker setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
        }
        [self presentViewController:picker animated:YES completion:NULL];
    }
}

-(void)clearFields
{
    tempCommentString=@"";
    self.txtVname.text=@"";
    self.txtVisitorEmail.text=@"";
    self.txtVisitorPhoneNumber.text=@"";
    fImage=nil;
    bImage=nil;
    self.rating=0;
    self.rateView.rating=0;
    self.frontImageView.image=nil;
    self.backImagView.image=nil;
    [self setTextViewValue];
}
- (IBAction)selectEvent:(id)sender
{
    [self gotoEvent:self];
}
#pragma mark User Selection Delegate Methods
-(void)selectedUserData:(id)data
{
    self.selectedonBehalfData=data;
    self.txtBehalf.text=[data objectForKey:rem_user_email];
}
#pragma mark Event Selection Delegate Methods
-(void)selectedEventData:(id)data
{
    self.selectedEventData=data;
    self.txtEname.text=[data objectForKey:event_eventName];
}
#pragma mark RateViewDelegate Method
-(void)rateView:(RateView *)rateView ratingDidChange:(float)ratingCustom
{
    self.rating=ratingCustom;
}
- (IBAction)saveCard:(UIButton *)sender
{
    BOOL visitorName=[CommonMethods checkEmptyString:self.txtVname.text];
    BOOL visitorNameEmail=[CommonMethods checkEmptyString:self.txtVisitorEmail.text];
    BOOL visitorPhone=[CommonMethods checkEmptyString:self.txtVisitorPhoneNumber.text];
    BOOL comment=NO;
    if(![self.txtComment.text isEqualToString:@"Comments"])
    {
        comment=YES;
    }
    if(!visitorName || comment || fImage || bImage || self.rating>0 || !visitorNameEmail || !visitorPhone)
    {
        [self saveCardToDB:^(BOOL isInsert) {
            if(isInsert)
            {
                [self vibrate];
                [self clearFields];
                dispatch_async(dispatch_get_main_queue(), ^{
                    [[AppDelegate getInstance]PlayProgressHudAsPerType:msg_Data_Insert View:nil];
                });
            }
            else
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [[AppDelegate getInstance]PlayProgressHudAsPerType:msg_Data_Insert_error View:nil];
                });
            }
        }];
    }
    else
    {
        [self vibrate];
        [[AppDelegate getInstance]PlayProgressHudAsPerType:@"Could not save blank card" View:nil];
    }
    
}
- (IBAction)showEvents:(id)sender
{
    BOOL visitorName=[CommonMethods checkEmptyString:self.txtVname.text];
    BOOL visitorNameEmail=[CommonMethods checkEmptyString:self.txtVisitorEmail.text];
    BOOL visitorPhone=[CommonMethods checkEmptyString:self.txtVisitorPhoneNumber.text];
    BOOL comment=NO;
    if(![self.txtComment.text isEqualToString:@"Comments"])
    {
        comment=YES;
    }
    if(!visitorName || comment || fImage || bImage || self.rating>0 || !visitorNameEmail || !visitorPhone)
    {
        [self vibrate];
        UIAlertView *alertToConfirmNavigation = [[UIAlertView alloc] initWithTitle:@"Unsaved data!" message:@"save and continue?" delegate:self cancelButtonTitle:@"NO! dont save" otherButtonTitles:@"YES! save and continue", nil];
        alertToConfirmNavigation.tag = 110;
        [alertToConfirmNavigation show];
    }
    else
    {
        [self clearFields];
        [self gotoEvent:nil];
    }
}
-(void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex{
    
    if(alertView.tag == 110){
        if(buttonIndex == 0)
        {
            [self clearFields];
            [self gotoEvent:nil];
        }
        else
        {
            //call Save funciton
            [self saveCardToDB:^(BOOL isInsert) {
                if(isInsert)
                {
                    [self clearFields];
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [[AppDelegate getInstance]PlayProgressHudAsPerType:msg_Data_Insert View:nil];
                        [self gotoEvent:nil];
                    });
                }
                else
                {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [[AppDelegate getInstance]PlayProgressHudAsPerType:msg_Data_Insert_error View:nil];
                        [self gotoEvent:nil];
                    });
                }
            }];
        }
    }
}
-(void)gotoEvent:(id)delegate
{
    EventsListTableViewController *eventList=[self.storyboard instantiateViewControllerWithIdentifier:@"EventsListTableViewController"];
    eventList.eventDelegate=delegate;
    eventList.title=@"Events";
    [self.navigationController pushViewController:eventList animated:YES];
}
#pragma mark -
#pragma mark vibrate device -
-(void)vibrate{
    if([[UIDevice currentDevice].model isEqualToString:@"iPhone"])
    {
        AudioServicesPlaySystemSound (kSystemSoundID_Vibrate); //1352
    }
    else
    {
        AudioServicesPlayAlertSound (kSystemSoundID_Vibrate); //1105
    }
}
-(void)saveCardToDB:(DBHandler)hanlder
{
    NSString *strComment=@"";
    NSString *strVEmail=@"";
    NSString *strPhoneNumber=@"";
    
    strVEmail=self.txtVisitorEmail.text;
    
    if (![CommonMethods checkEmptyString:self.txtVisitorPhoneNumber.text])
    {
        strPhoneNumber=self.txtVisitorPhoneNumber.text;
        
    }
    
    if(![self.txtComment.text isEqualToString:@"Comments"])
    {
        strComment=self.txtComment.text;
    }
    
    
    CardInfoModel *cardInfo=[[CardInfoModel alloc]init];
    NSInteger noOfImages=0;
    if (fImage && bImage) {
        noOfImages=2;
    }
    else if(bImage || fImage )
        noOfImages=1;
    
    cardInfo.visitorEmail=strVEmail;
    cardInfo.visitorPhone=strPhoneNumber;
    cardInfo.userId=[NSNumber numberWithInteger:[[[USER_DEFAULTS objectForKey:rem_user_Info]objectForKey:rem_user_id]integerValue]];
    cardInfo.eventName=[self.selectedEventData objectForKey:event_eventName];
    cardInfo.eventId=[NSNumber numberWithInteger:[[self.selectedEventData objectForKey:event_eventID] integerValue]];
    cardInfo.userEmail=[[USER_DEFAULTS objectForKey:rem_user_Info]objectForKey:rem_user_email];
    cardInfo.name=self.txtVname.text;
    
    if(fImage)
    {
        NSString *strFileName=[NSString stringWithFormat:@"Front_%@.jpg",[CommonMethods getFileName]];
        cardInfo.image1Path=strFileName;
        NSData *data=UIImageJPEGRepresentation(fImage, 1);
        [data writeToFile:[[AppDelegate getInstance]filePathWithFolder:strFileName folder:[NSString stringWithFormat:@"%@",cardInfo.userId]] atomically:YES];
    }
    else
        cardInfo.image1Path=@"";
    
    if(bImage)
    {
        NSString *strFileName=[NSString stringWithFormat:@"Back_%@.jpg",[CommonMethods getFileName]];
        cardInfo.image2Path=strFileName;
        NSData *data=UIImageJPEGRepresentation(bImage, 1);
        [data writeToFile:[[AppDelegate getInstance]filePathWithFolder:strFileName folder:[NSString stringWithFormat:@"%@",cardInfo.userId]] atomically:YES];
    }
    else
        cardInfo.image2Path=@"";
    
    cardInfo.eventDate=[self getDate];
    cardInfo.comments=strComment;
    cardInfo.isSynced=[NSNumber numberWithInteger:0];
    cardInfo.entryID=[NSNumber numberWithInteger:0];
    cardInfo.rating=[NSString stringWithFormat:@"%d",(int)self.rating];
    cardInfo.behalfUserId=[NSNumber numberWithInteger:[[USER_DEFAULTS objectForKey:rem_user_id] integerValue]];
    cardInfo.createdDate=[self getDate];
    cardInfo.modifiedDate=[self getDate];
    cardInfo.noOfImages=[NSNumber numberWithInteger:noOfImages];
    [DBOperations   addCard:cardInfo Block:hanlder];
}
-(NSString *)getDate
{
    NSDate *currentDate=[NSDate date];
    
    NSDateFormatter *formatter=[[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"dd-mm-YYYY HH:mm"];
    NSString *dateStr=[formatter stringFromDate:currentDate];
    return dateStr;
}

-(void)scanQR
{
    ZBarReaderViewController *reader = [ZBarReaderViewController new];
    reader.readerDelegate = self;
    reader.supportedOrientationsMask = ZBarOrientationMaskAll;
    ZBarImageScanner *scanner = reader.scanner;
    [scanner setSymbology: ZBAR_I25
                   config: ZBAR_CFG_ENABLE
                       to: 0];
    [self presentViewController:reader animated:YES completion:nil];
}
@end