//
//  ForgotPasswordViewController.m
//  VisitorsData
//
//  Created by webwerks on 05/10/15.
//  Copyright © 2015 Neosofttech. All rights reserved.
//

#import "ForgotPasswordViewController.h"
#import "AppDelegate.h"
#import "ErrorMessages.h"
#import "AppKeys.h"
#import "Constant.h"
#import "WebServiceHandler.h"
#import "NSString+Validation.h"
#import "ErrorMessages.h"
@interface ForgotPasswordViewController ()

@end

@implementation ForgotPasswordViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    UIImageView *arrow = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"emailID"]];
    arrow.frame = CGRectMake(0.0, 0.0, arrow.image.size.width+10.0, arrow.image.size.height);
    arrow.contentMode = UIViewContentModeCenter;
    self.emailTextField.leftViewMode=UITextFieldViewModeAlways;
    self.emailTextField.leftView=arrow;
    [self.emailTextField resignFirstResponder];
    
    [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:0.988 green:0.129 blue:0.176 alpha:1]];
    self.navigationController.navigationBar.tintColor=[UIColor whiteColor];
    self.navigationItem.title=@"Forgot Password";

}
-(void)viewWillAppear:(BOOL)animated
{
    self.navigationController.navigationBarHidden=NO;

    [self autoLayout];
}
-(void)autoLayout
{
    if (IS_IPHONE6PLUS) {
        self.viewVerticalSpacing.constant=135;
    }
    else if (IS_IPHONE6)
        self.viewVerticalSpacing.constant=100;
    else if(IS_IPHONE5)
        self.viewVerticalSpacing.constant=80;
    else
        self.viewVerticalSpacing.constant=40;
}
-(void)viewDidAppear:(BOOL)animated
{
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self.emailTextField resignFirstResponder];
    return YES;
}
- (IBAction)forgotPassword:(id)sender {
    
    NSString *email=_emailTextField.text;
    NSString *strEmail=[email  stringByTrimmingCharactersInSet:
                        [NSCharacterSet whitespaceCharacterSet]];
   
    if ([strEmail length]==0)
    {
        [[AppDelegate getInstance]PlayProgressHudAsPerType:msg_Check_Email View:nil];
        return;
    }
    BOOL validateEmail=[email isValid];
    if (!validateEmail)
    {
        [[AppDelegate getInstance]PlayProgressHudAsPerType:msg_Check_Email View:nil];
        _emailTextField.text=@"";
        return;
    }
  
    BOOL isIntenet=[[AppDelegate getInstance] CheckNetWorkConnection];
    if(!isIntenet)
    {
        
        [[AppDelegate getInstance]PlayProgressHudAsPerType:msg_Internet_Connection View:self.view];
        return ;
    }
    [[AppDelegate    getInstance]showHud:nil Title:nil];
    NSDictionary *emailDict=[[NSDictionary alloc]initWithObjectsAndKeys:email,@"email", nil];

    [[WebServiceHandler sharedInstance]callPostWSWithMethod:Forgot_Password_Service Parameters:emailDict Completion:^(id response, NSError *error)
    {
        [[AppDelegate    getInstance]closeHud];
        if(response)
        {
            NSString *message=[response objectForKey:@"message"];
            [AppDelegate showAlert:@"Visitor Data" withStatus:message];
            return ;
        }
        [AppDelegate showAlert:@"Visitor Data" withStatus:msg_Internet_Error];
    }];
   
}
@end
