//
//  LoginViewController.m
//  NeoVisitor
//
//  Created by webwerks on 22/02/16.
//  Copyright © 2016 webwerks. All rights reserved.
//

#import "LoginViewController.h"
#import "AppDelegate.h"
#import <AudioToolbox/AudioToolbox.h>
#import "VisitorFormController.h"
#import "ForgotPasswordViewController.h"
#import "resetPasswordViewController.h"
#import "ErrorMessages.h"
#import "AppKeys.h"
#import "Constant.h"
#import "NSString+EnCrypt.h"

@interface LoginViewController (){
    bool isShowPass;
}
@end
@implementation LoginViewController
@synthesize txtEmail,txtPassword;
#pragma mark - View lifecycle methods
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.txtEmail.autocorrectionType = UITextAutocorrectionTypeNo;
    self.txtPassword.secureTextEntry = YES;
    isShowPass = false;
    self.showPass.titleLabel.lineBreakMode = NSLineBreakByWordWrapping;
    self.showPass.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.showPass.tintColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5];
    _btnSignIn.layer.cornerRadius = 10;
    self.txtEmail.leftViewMode=UITextFieldViewModeAlways;
    [self addLeftView:@"emailID" TextField:self.txtEmail];
    [self addLeftView:@"password" TextField:self.txtPassword];
}
-(void)addLeftView:(NSString  *)imgName TextField:(UITextField *)txtField
{
    UIImageView *arrow = [[UIImageView alloc] initWithImage:[UIImage imageNamed:imgName]];
    
    arrow.frame = CGRectMake(0.0, 0.0, arrow.image.size.width+10.0, arrow.image.size.height);
    arrow.contentMode = UIViewContentModeCenter;
    txtField.leftViewMode=UITextFieldViewModeAlways;
    txtField.leftView=arrow;
    
}
-(void)viewWillAppear:(BOOL)animated
{
    self.navigationController.navigationBarHidden=YES;
    if([USER_DEFAULTS boolForKey:rem_remeber])
    {
        NSDictionary *userinfo=[USER_DEFAULTS objectForKey:rem_user_Info];
        self.txtEmail.text = [userinfo objectForKey:rem_user_email];
        self.txtPassword.text = [userinfo valueForKey:rem_user_password];
    }
    self.view.backgroundColor=[UIColor colorWithRed:0.85 green:0.87 blue:0.88 alpha:1.0];
    [self autoLayout];
}
-(void)autoLayout
{
    if (IS_IPHONE6)
    {
        self.viewVerticalSpacing.constant=100;
    }
    else if(IS_IPHONE6PLUS)
        self.viewVerticalSpacing.constant=120;
}
#pragma mark - UITextField delegates
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
#pragma mark - Button actions
- (IBAction)rememberMe:(id)sender
{
    
    if(self.rememberMe.isOn)
    {
        [USER_DEFAULTS setBool:YES forKey:rem_remeber];
    }
    else
    {
        [USER_DEFAULTS setBool:NO forKey:rem_remeber];
    }
}
- (IBAction)showPass:(id)sender
{
    if(isShowPass)
    {
        self.txtPassword.secureTextEntry = YES;
        isShowPass = false;
        self.showPass.tintColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5];
    }
    else{
        self.txtPassword.secureTextEntry = NO;
        isShowPass = true;
        self.showPass.tintColor = [UIColor blackColor];
    }
}
-(IBAction)checkAuthentication:(id)sender
{
    NSString *strEmail=[self.txtEmail.text stringByTrimmingCharactersInSet:
                        [NSCharacterSet whitespaceCharacterSet]];
    NSString *strPassword=[self.txtPassword.text stringByTrimmingCharactersInSet:
                           [NSCharacterSet whitespaceCharacterSet]];
    
    if ([strEmail length]==0)
    {
        [self shakeAnimation:(NSInteger *)1];
        [[AppDelegate getInstance]PlayProgressHudAsPerType:msg_Check_Email View:nil];
        return;
    }
    else if ([strPassword length]==0)
    {
        [self shakeAnimation:(NSInteger *)2];
        [[AppDelegate getInstance]PlayProgressHudAsPerType:msg_Check_Password View:nil];
        return;
    }
    NSString *strMD5Password = [strPassword enCryptString];
    
    NSPredicate *predicates=[NSPredicate predicateWithFormat:@"email=[c]%@ and password=%@",strEmail,strMD5Password];
    NSArray *arr=[[AppDelegate getInstance].arrAppUsers filteredArrayUsingPredicate:predicates];
    
    if([arr count]>0)
    {
        [self rememberMe:self.rememberMe];
        [self.view endEditing:YES];
        
        
        NSMutableDictionary *dict=[[NSMutableDictionary alloc]init];
        [dict addEntriesFromDictionary:[arr firstObject]];
        [dict setObject:strPassword forKey:rem_user_password];
        [USER_DEFAULTS setValue:dict forKey:rem_user_Info];
        [USER_DEFAULTS synchronize];
        VisitorFormController *obj = [self.storyboard instantiateViewControllerWithIdentifier:@"VisitorFormController"];
        [self.navigationController pushViewController:obj animated:YES];
    }
    else
    {
        [self shakeAnimation:(NSInteger *)0];
        [[AppDelegate getInstance]PlayProgressHudAsPerType:msg_Wrong_EmailPassword    View:nil];
    }
}
- (IBAction)resetPassword:(id)sender {
    self.navigationController.navigationBarHidden=NO;
    resetPasswordViewController *reset=[self.storyboard instantiateViewControllerWithIdentifier:@"resetPasswordViewController"];
    [self.navigationController pushViewController:reset animated:YES];
}
- (IBAction)forgotPassword:(id)sender {
    self.navigationController.navigationBarHidden=NO;
    ForgotPasswordViewController *forgot=[self.storyboard instantiateViewControllerWithIdentifier:@"ForgotPasswordViewController"];
    [self.navigationController pushViewController:forgot animated:YES];
}
#pragma mark - Shake animation
-(void)shakeAnimation:(NSInteger *)i{
    
    int temp = (int)i;
    
    if([[UIDevice currentDevice].model isEqualToString:@"iPhone"])
    {
        AudioServicesPlaySystemSound (kSystemSoundID_Vibrate); //1352
    }
    else
    {
        AudioServicesPlayAlertSound (kSystemSoundID_Vibrate); //1105
    }
    
    CAKeyframeAnimation *animation = [CAKeyframeAnimation animationWithKeyPath:@"transform.translation.x"];
    animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
    animation.duration = 0.6;
    animation.values = @[ @(-10), @(10), @(-10), @(10), @(-10), @(10), @(-5), @(5), @(0) ];
    
    if(temp == 1){
        [self.txtEmail.layer addAnimation:animation forKey:@"shake"];
    }
    else if (temp == 2){
        [self.txtPassword.layer addAnimation:animation forKey:@"shake"];
    }
    else{
        [self.view.layer addAnimation:animation forKey:@"shake"];
    }
}
@end
