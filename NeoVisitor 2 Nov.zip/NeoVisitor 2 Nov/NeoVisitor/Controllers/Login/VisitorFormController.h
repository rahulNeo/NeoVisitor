//
//  VisitorFormController.h
//  VisitorsData
//
//  Created by Pervacio on 10/19/14.
//  Copyright (c) 2014 Neosofttech. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RateView.h"
#import "DoneCancelNumberPadToolbar.h"
#import "MLKMenuPopover.h"
#import "ZBarSDK.h"
#import "TPKeyboardAvoidingScrollView.h"
@interface VisitorFormController : UIViewController<UITextFieldDelegate ,UIImagePickerControllerDelegate,UIAlertViewDelegate,UINavigationControllerDelegate,RateViewDelegate,DoneCancelNumberPadToolbarDelegate>
{
    UIImage *fImage;
    UIImage *bImage;
    UIImagePickerController *picker;
}
@property (weak, nonatomic) IBOutlet RateView *rateView;
@property (weak, nonatomic) IBOutlet UIButton *btnSave;
@property (strong, nonatomic) IBOutlet UIImageView *frontImageView;
@property (strong, nonatomic) IBOutlet UIImageView *backImagView;
@property(nonatomic,strong) MLKMenuPopover *menuPopover;
@property(nonatomic,strong) NSArray *menuItems;



@property(weak,nonatomic) IBOutlet UITextField *txtEname;
@property(weak,nonatomic) IBOutlet UITextField *txtBehalf;
@property(weak,nonatomic) IBOutlet UITextField *txtVname;
@property (weak, nonatomic) IBOutlet UITextField *txtVisitorEmail;
@property (weak, nonatomic) IBOutlet UITextField *txtVisitorPhoneNumber;

@property (weak, nonatomic) IBOutlet UITextView *txtComment;
 @property (weak, nonatomic) IBOutlet TPKeyboardAvoidingScrollView *mainScroll;
@property (weak, nonatomic) IBOutlet UIView *baseView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *fImageHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bImageHeight;
- (IBAction)saveCard:(UIButton *)sender;
- (IBAction)showEvents:(id)sender;
- (IBAction)selectEvent:(id)sender;
- (IBAction)frontImageSelected:(id)sender;
- (IBAction)BackImageSelected:(id)sender;
@property (weak, nonatomic) IBOutlet UIImageView *backgroundImageView;

@end
