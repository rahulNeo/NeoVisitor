//
//  resetPasswordViewController.h
//  VisitorsData
//
//  Created by webwerks on 05/10/15.
//  Copyright © 2015 Neosofttech. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TPKeyboardAvoidingScrollView.h"
@interface resetPasswordViewController : UIViewController<UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITextField *email;
@property (weak, nonatomic) IBOutlet UITextField *password;
@property (weak, nonatomic) IBOutlet UITextField *confirmPassword;
@property (weak, nonatomic) IBOutlet TPKeyboardAvoidingScrollView *scrollView;
- (IBAction)resetPass:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *confirmPassword1;

@end
