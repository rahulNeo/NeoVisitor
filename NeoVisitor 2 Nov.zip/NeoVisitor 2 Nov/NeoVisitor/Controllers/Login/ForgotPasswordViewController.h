//
//  ForgotPasswordViewController.h
//  VisitorsData
//
//  Created by webwerks on 05/10/15.
//  Copyright © 2015 Neosofttech. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TPKeyboardAvoidingScrollView.h"
@interface ForgotPasswordViewController : UIViewController<UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITextField *emailTextField;
@property (weak, nonatomic) IBOutlet TPKeyboardAvoidingScrollView *scrollView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *viewVerticalSpacing;
- (IBAction)forgotPassword:(id)sender;

@end
