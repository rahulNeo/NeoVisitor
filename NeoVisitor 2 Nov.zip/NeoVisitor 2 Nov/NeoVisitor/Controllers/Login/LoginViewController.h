//
//  LoginViewController.h
//  NeoVisitor
//
//  Created by webwerks on 22/02/16.
//  Copyright © 2016 webwerks. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TPKeyboardAvoidingScrollView.h"

@interface LoginViewController : UIViewController
- (IBAction)forgotPassword:(id)sender;
@property (weak, nonatomic) IBOutlet TPKeyboardAvoidingScrollView *scrollView;
@property(weak,nonatomic) IBOutlet UITextField *txtEmail;
@property(weak,nonatomic) IBOutlet UITextField *txtPassword;
@property (weak, nonatomic) IBOutlet UIButton *btnSignIn;
@property (weak, nonatomic) IBOutlet UISwitch *rememberMe;
@property (weak, nonatomic) IBOutlet UIButton *showPass;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *emailTopSpace;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *viewHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *eyeTopSpace;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *viewVerticalSpacing;
- (IBAction)showPass:(id)sender;
- (IBAction)rememberMe:(id)sender;
-(IBAction)checkAuthentication:(id)sender;
- (IBAction)resetPassword:(id)sender;
@end
