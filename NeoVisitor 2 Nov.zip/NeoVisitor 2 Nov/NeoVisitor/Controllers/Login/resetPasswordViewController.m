//
//  resetPasswordViewController.m
//  VisitorsData
//
//  Created by webwerks on 05/10/15.
//  Copyright © 2015 Neosofttech. All rights reserved.
//

#import "resetPasswordViewController.h"
#import "AppDelegate.h"
#import "ErrorMessages.h"
#import "AppKeys.h"
#import "Constant.h"
#import "WebServiceHandler.h"
#import "NSString+Validation.h"
#import "ErrorMessages.h"
#import "NSString+EnCrypt.h"

@interface resetPasswordViewController ()

@end

@implementation resetPasswordViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self addLeftView:@"emailID" TextField:self.email];
    [self addLeftView:@"password" TextField:self.password];
    [self addLeftView:@"password" TextField:self.confirmPassword];
    [self addLeftView:@"password" TextField:self.confirmPassword1];

    [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithRed:0.988 green:0.129 blue:0.176 alpha:1]];
    self.navigationController.navigationBar.tintColor=[UIColor whiteColor];
    self.navigationItem.title=@"Reset Password";
}
-(void)addLeftView:(NSString  *)imgName TextField:(UITextField *)txtField
{
    UIImageView *arrow = [[UIImageView alloc] initWithImage:[UIImage imageNamed:imgName]];
    
    arrow.frame = CGRectMake(0.0, 0.0, arrow.image.size.width+10.0, arrow.image.size.height);
    arrow.contentMode = UIViewContentModeCenter;
    txtField.leftViewMode=UITextFieldViewModeAlways;
    txtField.leftView=arrow;
    [txtField setDelegate:self];
}
-(void)viewWillAppear:(BOOL)animated
{
    self.navigationController.navigationBarHidden=NO;

     [self textBorder:self.email];
    [self textBorder: self.password];
    [self textBorder:self.confirmPassword1];
    [self textBorder:self.confirmPassword];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)resetPass:(id)sender
{
    NSString *strOldPassword=[_password.text  stringByTrimmingCharactersInSet:
                              [NSCharacterSet whitespaceCharacterSet]];
    
    NSString *strConfirmPassword=[self.confirmPassword.text  stringByTrimmingCharactersInSet:
                                  [NSCharacterSet whitespaceCharacterSet]];
    
    NSString *strReConfirmPassword=[self.confirmPassword1.text  stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    
    NSString *strEmail=[_email.text  stringByTrimmingCharactersInSet:
                        [NSCharacterSet whitespaceCharacterSet]];
    
    BOOL validateEmail=[strEmail isValid];
    
    if ([strEmail length]==0)
    {
        [[AppDelegate getInstance]PlayProgressHudAsPerType:msg_Check_Email View:nil];
        return;
    }
    else if (!validateEmail)
    {
        [[AppDelegate getInstance]PlayProgressHudAsPerType:msg_Check_Email View:nil];
        return;
    }
    else if ([strOldPassword length]==0)
    {
        [[AppDelegate getInstance]PlayProgressHudAsPerType:msg_Check_Password View:nil];
        return;
    }
    else if ([strConfirmPassword length]==0)
    {
        [[AppDelegate getInstance]PlayProgressHudAsPerType:@"Please Enter Confirm Password" View:nil];
        return;
    }
    else if (![strConfirmPassword isEqualToString:strReConfirmPassword])
    {
        [[AppDelegate getInstance]PlayProgressHudAsPerType:@"Your new password doesn't match with the confirmation password" View:nil];
        return;
    }
    
    NSString *strMD5Password = [strOldPassword enCryptString];
    NSPredicate *predicates=[NSPredicate predicateWithFormat:@"email=[c]%@ and password=%@",strEmail,strMD5Password];
    NSArray *arr=[[AppDelegate getInstance].arrAppUsers filteredArrayUsingPredicate:predicates];
    if([arr count]>0)
    {
        BOOL isIntenet=[[AppDelegate getInstance] CheckNetWorkConnection];
        if(!isIntenet)
        {
            
            [[AppDelegate getInstance]PlayProgressHudAsPerType:msg_Internet_Connection View:self.view];
            return ;
        }
        NSString *strUserId=[[arr firstObject]objectForKey:@"id"];
        [[AppDelegate    getInstance]showHud:nil Title:nil];
        NSDictionary *dict=[[NSDictionary alloc]initWithObjectsAndKeys:strConfirmPassword,@"new_password",strOldPassword,@"old_password",strUserId,@"user_id", nil];
        
        [[WebServiceHandler sharedInstance]callPostWSWithMethod:Forgot_Password_Service Parameters:dict Completion:^(id response, NSError *error)
         {
             [[AppDelegate    getInstance]closeHud];
             if(response)
             {
                 NSString *message=[response objectForKey:@"message"];
                 [AppDelegate showAlert:@"Visitor Data" withStatus:message];
                 return ;
             }
             [AppDelegate showAlert:@"Visitor Data" withStatus:msg_Internet_Error];
         }];
    }
    else
    {
        [[AppDelegate getInstance]PlayProgressHudAsPerType:msg_Wrong_EmailPassword    View:nil];
    }
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self.password resignFirstResponder];
    [self.confirmPassword resignFirstResponder];
    [self.email resignFirstResponder];
    [self.confirmPassword1 resignFirstResponder];
    return YES;
}
-(void)textBorder:(UITextField *)textField
{
    CALayer *border = [CALayer layer];
    CGFloat borderWidth = 2;
    border.borderColor = [UIColor whiteColor].CGColor;
    if(IS_IPHONE6PLUS)
    {
        if (textField == self.confirmPassword1) {
            border.frame = CGRectMake(0, textField.frame.size.height - borderWidth, textField.frame.size.width+90, 1.0f);

        }
        else
        border.frame = CGRectMake(0, textField.frame.size.height - borderWidth, textField.frame.size.width+85, 1.0f);
 
    }
    else
    border.frame = CGRectMake(0, textField.frame.size.height - borderWidth, textField.frame.size.width+60, 1.0f);
    border.borderWidth = borderWidth;
    [textField.layer addSublayer:border];
    textField.layer.masksToBounds = YES;
}

@end
