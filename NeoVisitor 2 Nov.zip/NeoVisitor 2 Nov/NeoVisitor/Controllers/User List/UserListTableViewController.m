//
//  UserListTableViewController.m
//  VisitorsData
//
//  Created by webwerks on 10/24/15.
//  Copyright © 2015 Neosofttech. All rights reserved.
//

#import "UserListTableViewController.h"
#import "AppDelegate.h"
#import "AppKeys.h"
#import "Constant.h"
@interface UserListTableViewController ()
{
    NSMutableArray *userList;
}
@end
@implementation UserListTableViewController
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationItem.title=@"Behalf Users";
}
#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [[AppDelegate getInstance].arrAppUsers   count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"UserList" forIndexPath:indexPath];
    NSDictionary *dict=[[AppDelegate getInstance].arrAppUsers  objectAtIndex:indexPath.row];
    NSArray *subStrings = [[dict objectForKey:rem_user_email] componentsSeparatedByString:@"@"];
    if([subStrings count]>0)
    {
        NSString *firstString = [subStrings objectAtIndex:0];
        cell.textLabel.text=firstString;
       
    }
    cell.accessoryType=UITableViewCellAccessoryNone;
    NSUInteger userId=[[dict objectForKey:rem_user_id]integerValue];
    NSUInteger behalfUserId=[[USER_DEFAULTS objectForKey:rem_user_id]integerValue];
    if(userId == behalfUserId)
    {
        cell.accessoryType=UITableViewCellAccessoryCheckmark;
    }
    
    else
    {
        cell.accessoryType=UITableViewCellAccessoryNone;
    }
    return cell;
}
#pragma mark - Table view delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([self.userDelegate respondsToSelector:@selector(selectedUserData:)])
    {
        NSDictionary *dict=[[AppDelegate getInstance].arrAppUsers  objectAtIndex:indexPath.row];
        [USER_DEFAULTS setObject:[dict objectForKey:rem_user_id] forKey:rem_user_id];
        [USER_DEFAULTS setObject:[dict objectForKey:rem_user_email] forKey:rem_user_email];

        [USER_DEFAULTS synchronize];
        [self.userDelegate  selectedUserData:[[AppDelegate getInstance].arrAppUsers  objectAtIndex:indexPath.row]];
        [self.navigationController popViewControllerAnimated:YES];
    }
}
@end
