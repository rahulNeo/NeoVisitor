//
//  UserListTableViewController.h
//  VisitorsData
//
//  Created by webwerks on 10/24/15.
//  Copyright © 2015 Neosofttech. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol UserListingDelegate<NSObject>
-(void)selectedUserData:(id)data;
@end
@interface UserListTableViewController : UITableViewController
@property(weak)id<UserListingDelegate>userDelegate;

@end
