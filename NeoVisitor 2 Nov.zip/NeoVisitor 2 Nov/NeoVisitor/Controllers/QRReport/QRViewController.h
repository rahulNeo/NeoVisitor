//
//  QRViewController.h
//  NeoVisitor
//
//  Created by webwerks on 29/02/16.
//  Copyright © 2016 webwerks. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <AddressBook/AddressBook.h>


@interface QRViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
}

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property(strong,nonatomic)NSArray *QRdata;
@property(strong,nonatomic)NSArray *QRVcardData;
- (IBAction)saveQRData:(id)sender;

@end
