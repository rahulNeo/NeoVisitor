//
//  QRViewController.m
//  NeoVisitor
//
//  Created by webwerks on 29/02/16.
//  Copyright © 2016 webwerks. All rights reserved.
//

#import "QRViewController.h"
#import "AppDelegate.h"
#import "EventsListTableViewController.h"
#import "CommonMethods.h"

@interface QRViewController ()<EventListingDelegate>
{
    NSMutableDictionary *QRdict;
    BOOL selectEvent;
    NSIndexPath *eventIndexPath;
    NSString *eventName;
}
@end

@implementation QRViewController
@synthesize QRdata,QRVcardData;
- (void)viewDidLoad {
    [super viewDidLoad];
    QRdata= [NSArray arrayWithObjects:@"Name",@"Full Name",@"Organisation",@"Email",@"Phone",@"Fax",@"Address",@"URL/Website",@"Select Event Name", nil];
    [self.tableView setBackgroundColor:[UIColor clearColor]];
    self.navigationItem.title=@"VCard";
    
    
    QRdict=[[NSMutableDictionary alloc]init];
    [QRdict setValue:@"" forKey:@"name"];
    [QRdict setValue:@"" forKey:@"fullName"];
    [QRdict setValue:@"" forKey:@"organisation"];
    [QRdict setValue:@"" forKey:@"email"];
    [QRdict setValue:@"" forKey:@"phone"];
    [QRdict setValue:@"" forKey:@"fax"];
    [QRdict setValue:@"" forKey:@"address"];
    [QRdict setValue:@"" forKey:@"url"];

    self.tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    
       for(NSString* line in QRVcardData) {
           [self parseLine:line];
}
    
}

-(void)viewWillAppear:(BOOL)animated
{
    //NSLog(@"data=%@",data);
    
    [self.tableView reloadData];
    
}



-(void)parseLine:(NSString *)line
{
    if ([line hasPrefix:@"BEGIN"]) {
        
    }
    
    else if ([line hasPrefix:@"END"])
    {
        
    }
    
    else if ([line hasPrefix:@"N:"])
        [self parseName:line];

    else if ([line hasPrefix:@"FN:"])
        [self parseFullName:line];
    
   
    
     else if ([line hasPrefix:@"EMAIL;"])
        [self parseEmail:line];
     else if ([line hasPrefix:@"ORG:"])
        [self parseORG : line];
    
     else if ([line hasPrefix:@"ADR;"] || [line hasPrefix:@"ADR:"])
        [self parseAdr:line];
     else if ([line hasPrefix:@"TEL;"] || [line hasPrefix:@"TEL:"])
        [self parseTel:line];
    
    
     else if ([line hasPrefix:@"URL;"] || [line hasPrefix:@"URL:"])
        [self parseURL:line];


}
-(void)parseName :(NSString *)name
{
    NSArray *upperComponents = [name componentsSeparatedByString:@":"];
    NSArray *components = [[upperComponents objectAtIndex:1] componentsSeparatedByString:@";"];
    [QRdict setValue:[components objectAtIndex:0] forKey:@"name"];

}
-(void)parseURL :(NSString *)url
{
    if ([url hasPrefix:@"URL;"]) {
        NSArray *upperComponents = [url componentsSeparatedByString:@":"];
        NSArray *upperComponents1 = [url componentsSeparatedByString:@";"];
        
        
        if ([[upperComponents1 objectAtIndex:1]hasPrefix:@"WORK"]) {
            [QRdict setValue:[upperComponents objectAtIndex:0] forKey:@"url"];
            
        }
    }
    else if ([url hasPrefix:@"URL:"])
    {
        NSArray *upperComponents = [url componentsSeparatedByString:@":"];
        [QRdict setValue:[upperComponents objectAtIndex:1] forKey:@"url"];


    }
    
}

-(void)parseEmail:(NSString *)email
{
    NSArray *upperComponents = [email componentsSeparatedByString:@":"];
    
    NSArray *upperComponents1 = [email componentsSeparatedByString:@";"];
    

    if ([[upperComponents1 objectAtIndex:1]hasPrefix:@"WORK"]) {
        [QRdict setValue:[upperComponents objectAtIndex:1] forKey:@"email"];
        
    }
}

-(void)parseFullName:(NSString *)fname
{
    NSArray *upperComponents = [fname componentsSeparatedByString:@":"];
    [QRdict setValue:[upperComponents objectAtIndex:1] forKey:@"fullName"];

}
-(void)parseORG:(NSString *)org
{
    NSArray *upperComponents = [org componentsSeparatedByString:@":"];
    [QRdict setValue:[upperComponents objectAtIndex:1] forKey:@"organisation"];


}
-(void)parseTel:(NSString *)tel
{
    if ([tel hasPrefix:@"TEL;"]) {
        NSArray *upperComponents = [tel componentsSeparatedByString:@":"];
        
        NSArray *upperComponents1 = [tel componentsSeparatedByString:@";"];
        
        if ([[upperComponents1 objectAtIndex:1]hasPrefix:@"WORK"]) {
            [QRdict setValue:[upperComponents objectAtIndex:1] forKey:@"phone"];
            
        }
        else if ([[upperComponents1 objectAtIndex:1]hasPrefix:@"FAX"])
        {
            [QRdict setValue:[upperComponents objectAtIndex:1] forKey:@"fax"];
        }

    }
    else if ([tel hasPrefix:@"TEL:"])
    {
        NSArray *upperComponents = [tel componentsSeparatedByString:@":"];
        [QRdict setValue:[upperComponents objectAtIndex:1] forKey:@"phone"];

    }
}

-(void)parseAdr:(NSString *)adr
{
    if ([adr hasPrefix:@"ADR;"]) {
        NSArray *upperComponents = [adr componentsSeparatedByString:@":"];
        NSArray *upperComponents1 = [adr  componentsSeparatedByString:@";"];
        
        if ([[upperComponents1 objectAtIndex:1]hasPrefix:@"WORK"]) {
            [QRdict setValue:[upperComponents objectAtIndex:1] forKey:@"address"];
        }
    }
    else if ([adr hasPrefix:@"ADR:"])
    {
        NSArray *upperComponents = [adr componentsSeparatedByString:@":"];
       // NSArray *upperComponents1 = [[upperComponents objectAtIndex:1]  componentsSeparatedByString:@";"];
        
        NSString *str=[[upperComponents objectAtIndex:1] stringByReplacingOccurrencesOfString:@";" withString:@" "];
        [QRdict setValue:str forKey:@"address"];

    }

}

-(void)gotoEvent:(id)delegate
{
    EventsListTableViewController *eventList=[self.storyboard instantiateViewControllerWithIdentifier:@"EventsListTableViewController"];
    eventList.eventDelegate=delegate;
    eventList.title=@"Events";
    [self.navigationController pushViewController:eventList animated:YES];
}

#pragma mark Event Selection Delegate Methods
-(void)selectedEventData:(id)data
{
    eventName=[data objectForKey:@"eventName"];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;    //count of section
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [QRdata count];    //count number of row from counting array hear cataGorry is An Array
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *MyIdentifier = @"MyIdentifier";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:MyIdentifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:MyIdentifier];
    }
    
    cell.textLabel.text=[QRdata objectAtIndex:indexPath.row];
    if (indexPath.row==0) {
        cell.detailTextLabel.text=[QRdict objectForKey:@"name"];
        
    }
    if (indexPath.row==1) {
        cell.detailTextLabel.text=[QRdict objectForKey:@"fullName"];
    }
    if (indexPath.row==2) {
        cell.detailTextLabel.text=[QRdict objectForKey:@"organisation"];
    }
    if (indexPath.row==3) {
        cell.detailTextLabel.text=[QRdict objectForKey:@"email"];
    }
    if (indexPath.row==4) {
        cell.detailTextLabel.text=[QRdict objectForKey:@"phone"];
    }
    if (indexPath.row==5) {
        cell.detailTextLabel.text=[QRdict objectForKey:@"fax"];
    }
    if (indexPath.row==6) {
        cell.detailTextLabel.text=[QRdict objectForKey:@"address"];
    }
    
    if (indexPath.row==7) {
        cell.detailTextLabel.text=[QRdict objectForKey:@"url"];
    }
    
    if (indexPath.row==8) {
        if ([CommonMethods checkEmptyString:eventName]) {
            cell.detailTextLabel.text=@"";

        }
        else
            cell.detailTextLabel.text=eventName;

    }
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row==8) {
        [self gotoEvent:self];
    }
}
-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    return [UIView new];
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    cell.textLabel.textColor=[UIColor redColor];
    [cell.textLabel setFont:[UIFont boldSystemFontOfSize:15]];

}
- (IBAction)saveQRData:(id)sender {
    [[AppDelegate getInstance]PlayProgressHudAsPerType:@"QR Data can not be saved at the moment" View:nil];
}
@end
