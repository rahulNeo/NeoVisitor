//
//  LoadingScreenViewController.m
//  NeoVisitor
//
//  Created by webwerks on 2/22/16.
//  Copyright © 2016 webwerks. All rights reserved.
//
#import "LoadingScreenViewController.h"
#import "AppDelegate.h"
#import "LoginViewController.h"
#import "ErrorMessages.h"
#import "WebServiceHandler.h"
#import "DBOperations.h"
@implementation LoadingScreenViewController
-(void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationController.navigationBarHidden=YES;
    BOOL isIntenet=[[AppDelegate getInstance] CheckNetWorkConnection];
    [DBOperations loadEventAndUsers];
    if(isIntenet)
    {
        [[WebServiceHandler sharedInstance]getListingDataFromServerUsingQueue:^(NSUInteger numberOfFinishedOperations, NSUInteger totalNumberOfOperations)
         { } Completion:^(id response, NSError *error)
         {
             [[AppDelegate getInstance].arrAppEvents removeAllObjects];
             [[AppDelegate getInstance].arrAppUsers removeAllObjects];
             [DBOperations loadEventAndUsers];
         }];
        [self performSelector:@selector(openLoginScreen) withObject:nil afterDelay:0.5];
    }
    else
    {
        [[AppDelegate getInstance]PlayProgressHudAsPerType:msg_Internet_Connection View:self.view];
        [self performSelector:@selector(openLoginScreen) withObject:nil afterDelay:0.3];
    }
}
-(void)openLoginScreen
{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self.actObj stopAnimating];
        LoginViewController *loginObj=[self.storyboard instantiateViewControllerWithIdentifier:@"LoginViewController"];
        [self.navigationController pushViewController:loginObj animated:NO];
        
    });
    
}
@end
