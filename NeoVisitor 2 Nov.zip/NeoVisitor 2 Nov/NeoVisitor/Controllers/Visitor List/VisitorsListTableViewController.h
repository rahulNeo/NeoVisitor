//
//  VisitorsListTableViewController.h
//  VisitorsData
//
//  Created by Aditya on 10/22/14.
//  Copyright (c) 2014 Neosofttech. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MFMailComposeViewController.h>
@interface VisitorsListTableViewController : UITableViewController<UIAlertViewDelegate,MFMailComposeViewControllerDelegate>

@property(strong,nonatomic) NSMutableArray *visitorsArray;
 @property(strong,nonatomic) NSNumber *eventID;

@end
