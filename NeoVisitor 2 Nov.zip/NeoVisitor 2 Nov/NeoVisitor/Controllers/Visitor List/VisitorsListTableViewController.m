//
//  VisitorsListTableViewController.m
//  VisitorsData
//
//  Created by Aditya on 10/22/14.
//  Copyright (c) 2014 Neosofttech. All rights reserved.
//

#import "VisitorsListTableViewController.h"
#import "EventsListTableViewController.h"
#import "DBOperations.h"
#import "AppDelegate.h"
#import "ErrorMessages.h"
#import "CardInfoKeys.h"
#import "UpdateViewController.h"
#import "WebServiceHandler.h"
#import "CommonMethods.h"
@interface VisitorsListTableViewController (){
    NSArray *recordsToSync;
    UISwipeGestureRecognizer *recognizer;
}

@property(strong,nonatomic)UIButton *deleteBtn;
@property(strong,nonatomic)UIButton *syncBtn;
@property(strong,nonatomic)UIButton *sendBtn;
@property(strong,nonatomic)NSIndexPath *cellIndex;

@end
//int cellIndex;
BOOL isLeftSwipe;
BOOL isRightSwipe;
BOOL isRightSwipeAfterDel;
BOOL isRightSwipeAfterSync;

CGFloat screenWidth;

@implementation VisitorsListTableViewController

@synthesize eventID;

#pragma mark -
#pragma mark - View lifecycle

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor= [UIColor whiteColor];
    UIButton *deleteAll = [UIButton buttonWithType:UIButtonTypeCustom];
    deleteAll.frame = CGRectMake(0.0, 0.0, 75, 25);
    [deleteAll setTitle:@"Delete all" forState:UIControlStateNormal];
    [deleteAll showsTouchWhenHighlighted];
    [deleteAll setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [deleteAll setBackgroundColor:[UIColor clearColor]];
    UIBarButtonItem *deleteAllButtonItem = [[UIBarButtonItem alloc] initWithCustomView:deleteAll];
    [deleteAll addTarget:self action:@selector(deleteAllMethod) forControlEvents:UIControlEventTouchUpInside];
    [self.navigationItem setRightBarButtonItem:deleteAllButtonItem];
    
    [self addGesture:UISwipeGestureRecognizerDirectionLeft Action:@selector(handleSwipeLeft:)];
    [self addGesture:UISwipeGestureRecognizerDirectionRight Action:@selector(handleSwipeRight:)];
    
    self.deleteBtn = [self getButton:@"Delete" Action:@selector(deleteMethod:) TintColor:[UIColor whiteColor] BGColor:[UIColor redColor]];
    //sync btn
    self.syncBtn = [self getButton:@"Sync" Action:@selector(syncMethod:) TintColor:[UIColor whiteColor] BGColor:[UIColor greenColor]];
    //send btn
    self.sendBtn = [self getButton:@"Send" Action:@selector(sendMethod:) TintColor:[UIColor whiteColor] BGColor:[UIColor blueColor]];
    
    isLeftSwipe = false;
    isRightSwipe = false;
    isRightSwipeAfterDel = false;
    isRightSwipeAfterSync = false;
    screenWidth = [UIScreen mainScreen].bounds.size.width;
}
-(UIButton *)getButton:(NSString *)strName Action:(SEL)sel TintColor:(UIColor *)tintColor BGColor:(UIColor *)bgColor
{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [btn addTarget:self
            action:sel
  forControlEvents:UIControlEventTouchUpInside];
    [btn setTitle:strName forState:UIControlStateNormal];
    btn.tintColor = tintColor;
    btn.backgroundColor = bgColor;
    [self.tableView addSubview:btn];
    return  btn;
}
-(void)addGesture:(UISwipeGestureRecognizerDirection)directon Action:(SEL)sel
{
    recognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:sel];
    [recognizer setDirection:(directon)];
    recognizer.delegate=(id)self;
    [self.tableView addGestureRecognizer:recognizer];
}
-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:YES];
    self.visitorsArray=[DBOperations getVistorCardByEventID:[NSNumber numberWithInteger:[eventID integerValue]]];
    if([self.visitorsArray count]==0)
    {
        [self.navigationItem setRightBarButtonItem:nil];
    }
    self.tableView.tableFooterView=[[UIView alloc]initWithFrame:CGRectZero];
    [self.tableView reloadData];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}
#pragma mark -
#pragma mark - Swipe gesture methods
- (void)handleSwipeLeft:(UISwipeGestureRecognizer *)gestureRecognizer
{
    if(!isLeftSwipe)
    {
        isLeftSwipe = true;
        //Get location of the swipe
        CGPoint location = [gestureRecognizer locationInView:self.tableView];
        
        //Get the corresponding index path within the table view
        NSIndexPath *indexPath = [self.tableView indexPathForRowAtPoint:location];
        
        //Check if index path is valid
        if(indexPath)
        {
            //Get the cell out of the table view
            UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
            [self.tableView setAllowsSelection:NO];
            self.cellIndex = indexPath;
            if([cell.detailTextLabel.text isEqualToString:@"Not Synced"]){
                self.deleteBtn.frame = CGRectMake(screenWidth + 225, cell.frame.origin.y, 75, cell.frame.size.height);
                self.syncBtn.frame = CGRectMake(screenWidth + 150, cell.frame.origin.y, 75, cell.frame.size.height);
                self.sendBtn.frame = CGRectMake(screenWidth + 75, cell.frame.origin.y, 75, cell.frame.size.height);
                [UIView animateWithDuration:0.5 animations:^(void){
                    self.deleteBtn.frame = CGRectMake(screenWidth - 75, cell.frame.origin.y, 75, cell.frame.size.height);
                    self.syncBtn.frame = CGRectMake(screenWidth - 150, cell.frame.origin.y, 75, cell.frame.size.height);
                    self.sendBtn.frame = CGRectMake(screenWidth - 225, cell.frame.origin.y, 75, cell.frame.size.height);
                } completion:^(BOOL finished){ }];
            }
            
            else{
                self.deleteBtn.frame = CGRectMake(screenWidth + 150, cell.frame.origin.y, 75, cell.frame.size.height);
                self.sendBtn.frame = CGRectMake(screenWidth + 75, cell.frame.origin.y, 75, cell.frame.size.height);
                [UIView animateWithDuration:0.5 animations:^(void){
                    self.deleteBtn.frame = CGRectMake(screenWidth - 75, cell.frame.origin.y, 75, cell.frame.size.height);
                    self.sendBtn.frame = CGRectMake(screenWidth - 150, cell.frame.origin.y, 75, cell.frame.size.height);
                    
                } completion:^(BOOL finished){}];
            }
        }
        isRightSwipe = false;
    }
}

- (void)handleSwipeRight:(UISwipeGestureRecognizer *)gestureRecognizer
{
    CGPoint location = [gestureRecognizer locationInView:self.tableView];
    NSIndexPath *indexPath = [self.tableView indexPathForRowAtPoint:location];
    
    
    if(!isRightSwipe && [indexPath isEqual:self.cellIndex]){
        
        isRightSwipe = true;
        //Check if index path is valid
        if(indexPath)
        {
            //Get the cell out of the table view
            UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
            
            if([cell.detailTextLabel.text isEqualToString:@"Not Synced"]){
                
                [UIView animateWithDuration:0.5 animations:^(void){
                    self.deleteBtn.frame = CGRectMake(cell.frame.origin.x + cell.frame.size.width + 150, cell.frame.origin.y, 100, cell.frame.size.height);
                    self.syncBtn.frame = CGRectMake(cell.frame.origin.x + cell.frame.size.width + 75, cell.frame.origin.y, 100, cell.frame.size.height);
                    self.sendBtn.frame = CGRectMake(cell.frame.origin.x + cell.frame.size.width, cell.frame.origin.y, 100, cell.frame.size.height);
                } completion:^(BOOL finished){
                    
                }];
            }
            else{
                [UIView animateWithDuration:0.5 animations:^(void){
                    self.deleteBtn.frame = CGRectMake(cell.frame.origin.x + cell.frame.size.width + 150, cell.frame.origin.y, 100, cell.frame.size.height);
                    self.sendBtn.frame = CGRectMake(cell.frame.origin.x + cell.frame.size.width + 75, cell.frame.origin.y, 100, cell.frame.size.height);
                } completion:^(BOOL finished){ }];
            }
            [self.tableView setAllowsSelection:YES];
        }
    }
    
    if (isRightSwipeAfterDel) {
        UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:self.cellIndex];
        if([cell.detailTextLabel.text isEqualToString:@"Not Synced"]){
            [UIView animateWithDuration:0.5 animations:^(void){
                self.deleteBtn.frame = CGRectMake(cell.frame.origin.x + cell.frame.size.width + 150, cell.frame.origin.y, 100, cell.frame.size.height);
                self.syncBtn.frame = CGRectMake(cell.frame.origin.x + cell.frame.size.width + 75, cell.frame.origin.y, 100, cell.frame.size.height);
                self.sendBtn.frame = CGRectMake(cell.frame.origin.x + cell.frame.size.width, cell.frame.origin.y, 100, cell.frame.size.height);
            } completion:^(BOOL finished){
            }];
        }
        else
        {
            [UIView animateWithDuration:0.5 animations:^(void){
                self.deleteBtn.frame = CGRectMake(cell.frame.origin.x + cell.frame.size.width + 150, cell.frame.origin.y, 100, cell.frame.size.height);
                self.sendBtn.frame = CGRectMake(cell.frame.origin.x + cell.frame.size.width + 75, cell.frame.origin.y, 100, cell.frame.size.height);
            } completion:^(BOOL finished){
            }];
        }
        [self.tableView setAllowsSelection:YES];
        isRightSwipeAfterDel = false;
    }
    if (isRightSwipeAfterSync) {
        
        UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:self.cellIndex];
        
        if([cell.detailTextLabel.text isEqualToString:@"Not Synced"]){
            
            [UIView animateWithDuration:0.5 animations:^(void){
                self.deleteBtn.frame = CGRectMake(cell.frame.origin.x + cell.frame.size.width + 150, cell.frame.origin.y, 100, cell.frame.size.height);
                self.syncBtn.frame = CGRectMake(cell.frame.origin.x + cell.frame.size.width + 75, cell.frame.origin.y, 100, cell.frame.size.height);
                self.sendBtn.frame = CGRectMake(cell.frame.origin.x + cell.frame.size.width , cell.frame.origin.y, 100, cell.frame.size.height);
            } completion:^(BOOL finished){
                
            }];
        }
        else{
            [UIView animateWithDuration:0.5 animations:^(void){
                self.deleteBtn.frame = CGRectMake(cell.frame.origin.x + cell.frame.size.width + 150, cell.frame.origin.y, 100, cell.frame.size.height);
                self.sendBtn.frame = CGRectMake(cell.frame.origin.x + cell.frame.size.width + 75, cell.frame.origin.y, 100, cell.frame.size.height);
            } completion:^(BOOL finished){
                
            }];
            
        }
        [self.tableView setAllowsSelection:YES];
        
        isRightSwipeAfterSync = false;
    }
    isLeftSwipe = false;
}
#pragma mark -
#pragma mark - Delete button
-(void)deleteMethod:(id)sender
{
    NSDictionary *dict=[self.visitorsArray objectAtIndex:self.cellIndex.row];
    
    BOOL isDeleted=[DBOperations deleteCard:0 row:[NSNumber numberWithInteger:[[dict objectForKey:@"rowID"] integerValue]] event:[dict objectForKey:card_eventId]];
    if(isDeleted)
    {
        [[AppDelegate getInstance]PlayProgressHudAsPerType:msg_Data_Delete View:nil];
        
        [[AppDelegate getInstance]deleteFileFromfolder:[dict objectForKey:card_image1Path] folder:[NSString stringWithFormat:@"%@",[dict objectForKey:card_userId]]];
        [[AppDelegate getInstance]deleteFileFromfolder:[dict objectForKey:card_image2Path] folder:[NSString stringWithFormat:@"%@",[dict objectForKey:card_userId]]];
        
        [self.visitorsArray removeObject:dict];
        if([self.visitorsArray count]==0)
        {
            [self.navigationItem setRightBarButtonItem:nil];
        }
        isRightSwipeAfterDel = true;
        [self handleSwipeRight:nil];
        [self.tableView reloadData];
    }
    else
    {
        isRightSwipeAfterDel = true;
        [self handleSwipeRight:nil];
        [[AppDelegate getInstance]PlayProgressHudAsPerType:msg_Data_Delete_error View:nil];
    }
}
-(void)deleteAllMethod
{
    if ([self.visitorsArray count]!=0)
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"NeoSoft" message:@"Are you sure you want to delete?" delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Yes, delete all entries", @"Delete only Synced entries" , nil];
        alert.tag = 111;
        [alert show];
    }
}
#pragma mark -
#pragma mark - Sync button
-(void)syncMethod:(id)sender{
    
    if(![[AppDelegate getInstance]CheckNetWorkConnection])
    {
        [[AppDelegate getInstance]PlayProgressHudAsPerType:msg_Internet_Connection View:self.view];
        return;
    }
    NSDictionary *dict=[self.visitorsArray objectAtIndex:self.cellIndex.row];
    NSMutableArray *arrData=[DBOperations getUnSyncCard:[dict objectForKey:card_rowID]];
    [[WebServiceHandler sharedInstance]SyncCardListingDataFromServerUsingQueue:^(id response, NSError *error)
     {
         
         
         isRightSwipeAfterSync = true;
         [self handleSwipeRight:nil];
         //isLeftSwipe=NO;
         
         NSMutableArray   *arr=[DBOperations getVistorCardByEventID:[NSNumber numberWithInteger:[eventID integerValue]] RowID:[dict objectForKey:card_rowID]];
         if([arr count]>0)
         {
             NSDictionary *dataDict=[arr firstObject];
             if ([[dataDict objectForKey:card_isSynced] integerValue]==0)
             {
                 [[AppDelegate getInstance]PlayProgressHudAsPerType:@"Not Synced" View:nil];
             }
             else
             {
                 [[AppDelegate getInstance]PlayProgressHudAsPerType:@"Card Synced" View:nil];
             }
             [self.visitorsArray replaceObjectAtIndex:self.cellIndex.row withObject:dataDict];
         }
         [self.tableView reloadData];
     } ArrRequest:arrData];
}
#pragma mark -
#pragma mark - Send button
-(void)sendMethod:(id)sender
{
    
    NSDictionary *dict=[self.visitorsArray objectAtIndex:self.cellIndex.row];
    if ([dict allKeys].count>0)
    {
        BOOL blConfig=[MFMailComposeViewController canSendMail];
        if (blConfig)
        {
            NSString *messageBody = [NSString stringWithFormat:@"<html><body><table border='1' cellpadding= '5'> <tr><td>Event Name</td><td>%@</td></tr>  <tr><td>Visitor Name</td><td>%@</td></tr>    <tr><td>Comments</td><td>%@</td></tr>   <tr><td>On Behalf</td><td>%@</td></tr>   <tr><td>Rating</td><td>%@</td></tr></table></body> </html>", [dict objectForKey:card_eventName],[dict objectForKey:card_name],[dict objectForKey:card_comments],[dict objectForKey:card_userEmail],[dict objectForKey:card_rating]];
            MFMailComposeViewController *mailComposer = [[MFMailComposeViewController alloc] init];
            [mailComposer setSubject:@""];
            [mailComposer setMessageBody:messageBody isHTML:YES];
            mailComposer.mailComposeDelegate = self;
            
            NSData *frontImage=[NSData dataWithContentsOfFile:[[AppDelegate getInstance]filePathWithFolder:[dict objectForKey:card_image1Path] folder:[NSString stringWithFormat:@"%@",[dict objectForKey:card_userId]]]];
            if([frontImage length]>0)
            {
                [mailComposer addAttachmentData:frontImage mimeType:@"image/jpeg" fileName:@"frontImage.jpeg"];
            }
            NSData *rearImage=[NSData dataWithContentsOfFile:[[AppDelegate getInstance]filePathWithFolder:[dict objectForKey:card_image2Path] folder:[NSString stringWithFormat:@"%@",[dict objectForKey:card_userId]]]];
            if([rearImage length]>0)
            {
                [mailComposer addAttachmentData:rearImage mimeType:@"image/jpeg" fileName:@"RearImage.jpeg"];
            }
            [self presentViewController:mailComposer animated:YES completion:nil];
        }
        else
        {
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error!!" message:@"Sorry Your Device Does not Supports Mailing Facility. Try using this function with some other device." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:Nil, nil];
            [alert show];
        }
    }
}
- (void) mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
    [self dismissViewControllerAnimated:YES completion:NULL];
}
#pragma mark -
#pragma mark - Alert view delegate
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if(alertView.tag == 111)
    {
        if(buttonIndex == 0)
        {
            return;
        }
        else if (buttonIndex == 1)
        {
            self.deleteBtn.frame=CGRectZero;
            self.syncBtn.frame=CGRectZero;
            self.sendBtn.frame=CGRectZero;
            isRightSwipeAfterDel = true;
            [self handleSwipeRight:nil];
            
            BOOL isDeleted=[DBOperations deleteCard:2 row:NULL event:[NSNumber numberWithInteger:[eventID integerValue]]];
            if(isDeleted)
            {
                for (NSDictionary *dict in self.visitorsArray)
                {
                    [[AppDelegate getInstance]deleteFileFromfolder:[dict objectForKey:card_image1Path] folder:[NSString stringWithFormat:@"%@",[dict objectForKey:card_userId]]];
                    [[AppDelegate getInstance]deleteFileFromfolder:[dict objectForKey:card_image2Path] folder:[NSString stringWithFormat:@"%@",[dict objectForKey:card_userId]]];
                }
                [self.visitorsArray removeAllObjects];
                [self.tableView reloadData];
                [[AppDelegate getInstance]PlayProgressHudAsPerType:msg_Data_Delete View:nil];
                if([self.visitorsArray count]==0)
                {
                    [self.navigationItem setRightBarButtonItem:nil];
                }
            }
            else
            {
                [[AppDelegate getInstance]PlayProgressHudAsPerType:msg_Data_Delete_error View:nil];
            }
        }
        else if (buttonIndex == 2)
        {
            self.deleteBtn.frame=CGRectZero;
            self.syncBtn.frame=CGRectZero;
            self.sendBtn.frame=CGRectZero;
            
            BOOL isDeleted=[DBOperations deleteCard:1 row:NULL event:[NSNumber numberWithInteger:[eventID integerValue]]];
            if(isDeleted)
            {
                NSPredicate *predicate=[NSPredicate predicateWithFormat:@"isSynced=1"];
                NSArray *arrSyncData=[self.visitorsArray filteredArrayUsingPredicate:predicate];
                for (NSDictionary *dict in arrSyncData)
                {
                    [[AppDelegate getInstance]deleteFileFromfolder:[dict objectForKey:card_image1Path] folder:[NSString stringWithFormat:@"%@",[dict objectForKey:card_userId]]];
                    [[AppDelegate getInstance]deleteFileFromfolder:[dict objectForKey:card_image2Path] folder:[NSString stringWithFormat:@"%@",[dict objectForKey:card_userId]]];
                }
                [self.visitorsArray removeAllObjects];
                [self.tableView reloadData];
                [[AppDelegate getInstance]PlayProgressHudAsPerType:msg_Data_Delete_sync View:nil];
                [self viewWillAppear:YES];
            }
            else
            {
                [[AppDelegate getInstance]PlayProgressHudAsPerType:msg_Data_Delete_error View:nil];
            }
        }
    }
}
#pragma mark -
#pragma mark - Table view delegates
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return [self.visitorsArray count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier =@"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    NSDictionary *temp;
    temp = [self.visitorsArray objectAtIndex:indexPath.row];
    BOOL visitorName=[CommonMethods checkEmptyString:[temp objectForKey:card_name]];
    BOOL comment=[CommonMethods checkEmptyString:[temp objectForKey:card_comments]];
    
    if (!visitorName)
    {
        cell.textLabel.text= [temp objectForKey:card_name];
    }
    else if (!comment)
    {
        cell.textLabel.text= [temp objectForKey:card_comments];
    }
    else
    {
        cell.textLabel.text= @"(Record)";
    }
    
    
    if ([[temp objectForKey:card_isSynced] integerValue]==0)
    {
        cell.detailTextLabel.textColor = [UIColor redColor];
        cell.detailTextLabel.text = @"Not Synced";
    }
    else
    {
        cell.detailTextLabel.textColor = [UIColor greenColor];
        cell.detailTextLabel.text = @"Synced";
    }
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(!isLeftSwipe)
    {
        UpdateViewController *obj = [self.storyboard instantiateViewControllerWithIdentifier:@"UpdateViewController"];
        obj.updateDetail=[self.visitorsArray objectAtIndex:indexPath.row];
        [self.navigationController pushViewController:obj animated:YES];
    }
}
@end
