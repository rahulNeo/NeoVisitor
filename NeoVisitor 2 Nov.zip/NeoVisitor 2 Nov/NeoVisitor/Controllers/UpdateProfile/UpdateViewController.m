//
//  UpdateViewController.m
//  NeoVisitor
//
//  Created by webwerks on 24/02/16.
//  Copyright © 2016 webwerks. All rights reserved.
//

#import "UpdateViewController.h"
#import "CardInfoKeys.h"
#import "CardInfoModel.h"
#import "AppDelegate.h"
#import "AppKeys.h"
#import "UserListTableViewController.h"
#import "CommonMethods.h"
#import "DBOperations.h"
#import "ErrorMessages.h"
#import "Constant.h"
#import "UIImage+Scaling.h"

@interface UpdateViewController ()
{
    NSString *tempCommentString;
    UIImage *fImage,*bImage;
    UIImagePickerController *picker;
    NSMutableDictionary *cameraOptions;
    KLCPopup *popUp;
    BOOL isBackImage;}
@end
@implementation UpdateViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    // Do any additional setup after loading the view.
    self.rateView.rating = 0;
    self.rateView.editable = YES;
    self.rateView.maxRating = 5;
    self.rateView.delegate=self;
    self.rateView.notSelectedImage = [UIImage imageNamed:@"greyStar"];
    self.rateView.fullSelectedImage = [UIImage imageNamed:@"yellowStar"];
    
    DoneCancelNumberPadToolbar *toolbar = [[DoneCancelNumberPadToolbar alloc] initWithTextField:self.txtComment];
    toolbar.delegate = self;
    self.txtComment.inputAccessoryView = toolbar;
    
    self.frontImageView.userInteractionEnabled=YES;
    
    
    
    UITapGestureRecognizer *gesture=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(frontImageSelected:)];
    [self.frontImageView addGestureRecognizer:gesture];
    self.frontImageView.userInteractionEnabled=YES;
    
    
    UITapGestureRecognizer *gesture1=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(BackImageSelected:)];
    [self.backImagView addGestureRecognizer:gesture1];
    self.backImagView.userInteractionEnabled=YES;
    [self initialiseValues];
}
-(void)viewWillAppear:(BOOL)animated
{
    [self autoLayout];
}
-(void)initialiseValues
{
    cameraOptions=[[NSMutableDictionary alloc]init];
    [cameraOptions setValue:@"Camera" forKey:@"Camera"];
    [cameraOptions setValue:@"Gallery" forKey:@"Gallery"];
    
    
    
    self.txtVisitorName.text=[self.updateDetail objectForKey:card_name];
    self.txtComment.text=[self.updateDetail objectForKey:card_comments];
    self.txtVisitorEmail.text=[self.updateDetail objectForKey:card_visitorEmail];
    self.txtVisitorPhoneNumber.text=[self.updateDetail objectForKey:card_visitorPhone];
    
    BOOL fileExists = [[NSFileManager defaultManager] fileExistsAtPath:[self checkImages:[self.updateDetail objectForKey:card_image1Path]]];
    
    if (fileExists) {
        UIImage *image=[UIImage imageWithContentsOfFile:[self checkImages:[self.updateDetail objectForKey:card_image1Path]]];
        fImage=image;
        self.frontImageView.image=fImage;
    }
    
    BOOL fileExists1 = [[NSFileManager defaultManager] fileExistsAtPath:[self checkImages:[self.updateDetail objectForKey:card_image2Path]]];
    
    if (fileExists1) {
        
        UIImage *image=[UIImage imageWithContentsOfFile:[self checkImages:[self.updateDetail objectForKey:card_image2Path]]];
        bImage=image;
        
        self.backImagView.image=bImage;
        
    }
    
    self.rateView.rating=[[self.updateDetail objectForKey:card_rating]floatValue];
    
    [self setupLeftView:self.txtVisitorName];
    [self setupLeftView:self.txtVisitorEmail];
    [self setupLeftView:self.txtVisitorPhoneNumber];
    tempCommentString = self.txtComment.text;
}
-(void)setupLeftView:(UITextField *)txtField
{
    UIView *leftView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 5, 20)];
    leftView.backgroundColor=[UIColor clearColor];
    txtField.leftView = leftView;
    txtField.leftViewMode = UITextFieldViewModeAlways;
}
-(NSString *)checkImages:(NSString *)fileName
{
    NSString *path=[[AppDelegate getInstance]filePathWithFolder:fileName folder:[[self.updateDetail objectForKey:card_userId] stringValue]];
    return path;
}
#pragma mark RateViewDelegate Method
-(void)rateView:(RateView *)rateView ratingDidChange:(float)ratingCustom
{
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark -
#pragma mark UITextField delegates -
-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    return YES;
}
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    [self setTextViewValue];
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (void)textViewDidBeginEditing:(UITextView *)textView
{
    if([self.txtComment.text isEqualToString:@"Comments"])
    {
        self.txtComment.text = @"";
        tempCommentString=@"";
        self.txtComment.textColor = [UIColor blackColor];
    }
    tempCommentString = self.txtComment.text;
}
- (void)textViewDidEndEditing:(UITextView *)textView
{
    tempCommentString = self.txtComment.text;
    [self setTextViewValue];
}
-(void)textFieldDidEndEditing:(UITextField *)textField
{
    [self setTextViewValue];
}
-(void)setTextViewValue
{
    tempCommentString=[tempCommentString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if([tempCommentString length]==0)
    {
        self.txtComment.textColor = [UIColor colorWithRed:0.7804 green:0.7804 blue:0.7804 alpha:1];
        self.txtComment.text = @"Comments";
    }
    else
    {
        self.txtComment.text = tempCommentString;
        self.txtComment.textColor = [UIColor blackColor];
    }
}
-(void)saveData:(DBHandler)hanlder
{
    CardInfoModel *cardInfo=[[CardInfoModel alloc]init];
    NSInteger noOfImages=0;
    if (fImage && bImage) {
        noOfImages=2;
    }
    else if(bImage || fImage )
        noOfImages=1;
    cardInfo.userId=[NSNumber numberWithInteger:[[[USER_DEFAULTS objectForKey:rem_user_Info]objectForKey:rem_user_id]integerValue]];
    cardInfo.eventName=[self.updateDetail objectForKey:event_eventName];
    cardInfo.eventId=[NSNumber numberWithInteger:[[self.updateDetail objectForKey:event_eventID] integerValue]];
    cardInfo.userEmail=[[USER_DEFAULTS objectForKey:rem_user_Info]objectForKey:rem_user_email];
    cardInfo.name=self.txtVisitorName.text;
    cardInfo.rowID=[NSNumber numberWithInteger:[[self.updateDetail objectForKey:card_rowID] integerValue]];
    
    if(fImage)
    {
        NSData *data=UIImageJPEGRepresentation(fImage, 1);
        BOOL fileExists = [[NSFileManager defaultManager] fileExistsAtPath:[self checkImages:[self.updateDetail objectForKey:card_image1Path]]];
        if(!fileExists)
        {
            NSString *strFileName=[NSString stringWithFormat:@"Front_%@.jpg",[CommonMethods getFileName]];
            cardInfo.image1Path=strFileName;
            
        }
        else
            cardInfo.image1Path=[self.updateDetail objectForKey:card_image1Path];
        
        [data writeToFile:[[AppDelegate getInstance]filePathWithFolder:cardInfo.image1Path folder:[NSString stringWithFormat:@"%@",cardInfo.userId]] atomically:YES];
        
    }
    else
        cardInfo.image1Path=@"";
    
    if(bImage)
    {
        NSData *data=UIImageJPEGRepresentation(bImage, 1);
        BOOL fileExists = [[NSFileManager defaultManager] fileExistsAtPath:[self checkImages:[self.updateDetail objectForKey:card_image2Path]]];
        if(!fileExists)
        {
            NSString *strFileName=[NSString stringWithFormat:@"Back_%@.jpg",[CommonMethods getFileName]];
            cardInfo.image2Path=strFileName;
            
        }
        else
            cardInfo.image2Path=[self.updateDetail objectForKey:card_image2Path];
        
        [data writeToFile:[[AppDelegate getInstance]filePathWithFolder:cardInfo.image2Path folder:[NSString stringWithFormat:@"%@",cardInfo.userId]] atomically:YES];
    }
    else
    {
        cardInfo.image2Path=@"";
    }
    NSString *strComment=@"";
    NSString *strVEmail=@"";
    NSString *phoneNumber=@"";
    strVEmail=self.txtVisitorEmail.text;
    
    
    if (![CommonMethods checkEmptyString:self.txtVisitorPhoneNumber.text])
    {
        phoneNumber=self.txtVisitorPhoneNumber.text ;
    }
    
    if(![self.txtComment.text isEqualToString:@"Comments"])
    {
        strComment=self.txtComment.text;
    }
    cardInfo.eventDate=[self getDate];
    cardInfo.visitorEmail=strVEmail;
    cardInfo.visitorPhone=phoneNumber;
    
    cardInfo.comments=strComment;
    cardInfo.isSynced=[NSNumber numberWithInteger:0];
    cardInfo.rating=[NSString stringWithFormat:@"%d",(int)self.rateView.rating];
    cardInfo.behalfUserId=[NSNumber numberWithInteger:[[USER_DEFAULTS objectForKey:rem_user_id] integerValue]];
    cardInfo.createdDate=[self getDate];
    cardInfo.modifiedDate=[self getDate];
    cardInfo.noOfImages=[NSNumber numberWithInteger:noOfImages];
    
    [DBOperations  updateCard:cardInfo Block:hanlder];
}
- (IBAction)closePopUp:(id)sender {
    [popUp dismissPresentingPopup];
}
- (IBAction)update:(id)sender {
    [self saveData:^(BOOL isInsert)
     {
         if (isInsert) {
             [[AppDelegate getInstance]PlayProgressHudAsPerType:msg_Data_Updated View:nil];
             [self.navigationController popViewControllerAnimated:YES];
         }
         else
         {
             [[AppDelegate getInstance]PlayProgressHudAsPerType:msg_Data_Insert_error View:nil];
         }
     } ];
    
}

-(NSString *)getDate
{
    NSDate *currentDate=[NSDate date];
    
    NSDateFormatter *formatter=[[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"dd-mm-YYYY HH:mm"];
    
    NSString *dateStr=[formatter stringFromDate:currentDate];
    return dateStr;
}

-(void)captureImage
{
    [self.view endEditing:YES];
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"Pick Source" delegate:(id)self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles: nil];
    
    NSString *camera=[cameraOptions objectForKey:@"Camera"];
    NSString *gallery=[cameraOptions objectForKey:@"Gallery"];
    NSString *full=[cameraOptions objectForKey:@"FullScreen"];
    
    if (![CommonMethods checkEmptyString:full])
    {
        [actionSheet addButtonWithTitle:full];
    }
    [actionSheet addButtonWithTitle:camera];
    [actionSheet addButtonWithTitle:gallery];
    actionSheet.tag=1;
    [actionSheet showInView:self.view];
}
#pragma mark -
#pragma mark Camera pickerView delegates -

- (void)imagePickerController:(UIImagePickerController *)picker1 didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    UIImage * imageToSave;
    UIImage * editedImage = (UIImage *) [info objectForKey: UIImagePickerControllerEditedImage];
    UIImage *originalImage = (UIImage *) [info objectForKey: UIImagePickerControllerOriginalImage];
    if (editedImage)
    {
        imageToSave = editedImage;
    }
    else
    {
        imageToSave = originalImage;
    }
    UIImage *bigImage=[imageToSave imageByScalingAndCroppingForSize:CGSizeMake(500, 500)];
    if(!isBackImage)
    {
        fImage=[[UIImage alloc]init];
        fImage=bigImage;
        self.frontImageView.image=fImage;
    }
    else
    {
        bImage=bigImage;
        self.backImagView.image=bigImage;
    }
    [picker1 dismissViewControllerAnimated:YES completion:NULL];
}
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker1 {
    
    if([self.txtComment.text isEqualToString:@""])
    {
        self.txtComment.textColor = [UIColor colorWithRed:0.7804 green:0.7804 blue:0.7804 alpha:1];
        self.txtComment.text = @"Comments";
    }
    [picker1 dismissViewControllerAnimated:YES completion:NULL];
}
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex!=0)
    {
        NSString *strTitle=[actionSheet buttonTitleAtIndex:buttonIndex];
        if([strTitle isEqualToString:@"View Full Screen"])
        {
            if (popUp) {
                popUp=nil;
            }
            if (isBackImage) {
                popUp=[KLCPopup popupWithContentView:[self createPopUpView:bImage]];            }
            else
                popUp=[KLCPopup popupWithContentView:[self createPopUpView:fImage]];
            
            
            
            [popUp show];
            return;
            
        }
        else if([strTitle isEqualToString:@"Camera"])
        {
            if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
            {
                [self loadPicker:UIImagePickerControllerSourceTypePhotoLibrary];
            }
            else
            {
                [self loadPicker:UIImagePickerControllerSourceTypeCamera];
            }
        }
        else if([strTitle isEqualToString:@"Gallery"])
        {
            [self loadPicker:UIImagePickerControllerSourceTypePhotoLibrary];
        }
    }
}
-(void)loadPicker:(UIImagePickerControllerSourceType)type
{
    picker = [[UIImagePickerController alloc] init];
    picker.delegate=self;
    picker.allowsEditing=true;
    picker.sourceType = type;
    [self presentViewController:picker animated:YES completion:NULL];
}
#pragma  mark DoneCancelNumberPadToolbar delegate methods
-(void)doneCancelNumberPadToolbarDelegate:(DoneCancelNumberPadToolbar *)controller didClickDone:(id)textField
{
    tempCommentString = self.txtComment.text;
    
    [self setTextViewValue];
}
-(void)doneCancelNumberPadToolbarDelegate:(DoneCancelNumberPadToolbar *)controller didClickCancel:(id)textField
{
    tempCommentString = self.txtComment.text;
    
    [self setTextViewValue];
}

- (IBAction)frontImageSelected:(id)sender
{
    if (fImage) {
        [cameraOptions setValue:@"View Full Screen" forKey:@"FullScreen"];
    }
    else
        [cameraOptions setValue:@"" forKey:@"FullScreen"];
    
    isBackImage=NO;
    [self captureImage];
    
}
- (IBAction)BackImageSelected:(id)sender
{
    if (bImage) {
        [cameraOptions setValue:@"View Full Screen" forKey:@"FullScreen"];
    }
    else
        [cameraOptions setValue:@"" forKey:@"FullScreen"];
    
    isBackImage=YES;
    [self captureImage];
    
}

-(void)autoLayout
{
    CGRect rect=[UIScreen mainScreen].bounds;
    float height=(rect.size.width-40)/2;
    self.fImageHeight.constant=height;
    self.bImageHeight.constant=height;
    
    if (IS_IPHONE6PLUS) {
        self.topSpace.constant=40;
        
    }
    else if(IS_IPHONE6)
    {
        self.topSpace.constant=40;
    }
    
}


-(UIView *)createPopUpView:(UIImage *)image
{
    UIView *FullImgeView=[[UIView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    FullImgeView.backgroundColor=[UIColor whiteColor];
    FullImgeView.layer.cornerRadius=8;
    UIImageView *img=[[UIImageView alloc]initWithFrame:FullImgeView.frame];
    UIButton *close=[[UIButton alloc]initWithFrame:CGRectMake(FullImgeView.frame.size.width-40, 30, 30, 30)];
    
    [close setImage:[UIImage imageNamed:@"closeButton"] forState:UIControlStateNormal];
    [close addTarget:self action:@selector(closePopUp:) forControlEvents:UIControlEventTouchUpInside];
    
    
    [FullImgeView addSubview:close];
    
    [FullImgeView addSubview:img];
    [img setImage:image];
    img.contentMode=UIViewContentModeScaleAspectFit;
    
    return FullImgeView;
}
@end
