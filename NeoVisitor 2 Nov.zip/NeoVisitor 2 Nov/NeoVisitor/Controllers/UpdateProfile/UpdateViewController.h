//
//  UpdateViewController.h
//  NeoVisitor
//
//  Created by webwerks on 24/02/16.
//  Copyright © 2016 webwerks. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RateView.h"
#import "DoneCancelNumberPadToolbar.h"
#import "KLCPopup.h"
#import "TPKeyboardAvoidingScrollView.h"
@interface UpdateViewController : UIViewController<UITextFieldDelegate ,UIImagePickerControllerDelegate,UIAlertViewDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,RateViewDelegate,DoneCancelNumberPadToolbarDelegate>
@property(strong,nonatomic)IBOutlet RateView *rateView;
@property (weak, nonatomic) IBOutlet UITextField *txtVisitorName;
@property (weak, nonatomic) IBOutlet UITextView *txtComment;
@property (weak, nonatomic) IBOutlet TPKeyboardAvoidingScrollView *scrollView;

@property (weak, nonatomic) IBOutlet UITextField *txtVisitorEmail;
@property (weak, nonatomic) IBOutlet UITextField *txtVisitorPhoneNumber;


@property (strong, nonatomic) IBOutlet UIImageView *frontImageView;
@property (strong, nonatomic) IBOutlet UIImageView *backImagView;

@property (weak, nonatomic) IBOutlet UIView *popUPView;

@property (weak, nonatomic) IBOutlet UIImageView *popUpImage;



- (IBAction)closePopUp:(id)sender;

- (IBAction)update:(id)sender;
- (void)frontImageSelected:(id)sender;
- (void)BackImageSelected:(id)sender;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *fImageHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bImageHeight;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topSpace;

@property(strong,nonatomic)NSMutableDictionary *updateDetail;
@end
