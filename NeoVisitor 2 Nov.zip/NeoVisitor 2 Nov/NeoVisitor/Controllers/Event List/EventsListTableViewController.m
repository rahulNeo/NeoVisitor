//
//  EventsListTableViewController.m
//  VisitorsData
//
//  Created by Aditya on 10/22/14.
//  Copyright (c) 2014 Neosofttech. All rights reserved.
//

#import "EventsListTableViewController.h"
#import "AppDelegate.h"
#import "AppKeys.h"
#import "VisitorsListTableViewController.h"
#import "DBOperations.h"
@interface EventsListTableViewController ()
@end
@implementation EventsListTableViewController
@synthesize eventDelegate;
#pragma mark - View life cycle
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationController.interactivePopGestureRecognizer.enabled = NO;
}
-(void)viewWillAppear:(BOOL)animated
{
    self.tableView.backgroundColor=[UIColor lightGrayColor];
    self.tableView.tableFooterView=[[UIView alloc]initWithFrame:CGRectZero];
    self.view.backgroundColor=[UIColor colorWithRed:0.85 green:0.87 blue:0.88 alpha:1.0];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([cell respondsToSelector:@selector(setSeparatorInset:)])
    {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)])
    {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    if ([cell respondsToSelector:@selector(setLayoutMargins:)])
    {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}
#pragma mark - Table view data source
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return  48.0;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return [[AppDelegate getInstance].arrAppEvents count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier =@"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    NSDictionary *dic=[[AppDelegate getInstance].arrAppEvents objectAtIndex:indexPath.row];
    NSString *temp;
    temp = [dic objectForKey:event_eventName];
    cell.textLabel.text= temp;
    cell.textLabel.numberOfLines=2;
    cell.textLabel.font=[UIFont systemFontOfSize:15.0];
    if ([self.eventDelegate respondsToSelector:@selector(selectedEventData:)])
    {
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *dic=[[AppDelegate getInstance].arrAppEvents objectAtIndex:indexPath.row];
    if ([self.eventDelegate respondsToSelector:@selector(selectedEventData:)])
    {
        [self.eventDelegate  selectedEventData:[[AppDelegate getInstance].arrAppEvents objectAtIndex:indexPath.row]];
        [self.navigationController popViewControllerAnimated:YES];
    }
    else
    {
        VisitorsListTableViewController *obj = [self.storyboard instantiateViewControllerWithIdentifier:@"VisitorsListTableViewController"];
        obj.title = [dic objectForKey:event_eventName];
        obj.eventID = [dic objectForKey:event_eventID];
        [self.navigationController pushViewController:obj animated:YES];
    }
}

-(void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath{
    

    NSDictionary *dic=[[AppDelegate getInstance].arrAppEvents objectAtIndex:indexPath.row];
   
    NSMutableDictionary *dataDict=[DBOperations getCardByEventID:[NSNumber numberWithInteger:[[dic objectForKey:event_eventID]integerValue]]];
    
    NSString *title = [ [[AppDelegate getInstance].arrAppEvents objectAtIndex:indexPath.row] objectForKey:event_eventName];
    
    NSString *message = [NSString stringWithFormat:@"Synced: %@\nTotal: %@", [dataDict objectForKey:@"Sync"], [dataDict objectForKey:@"Total"]];
    
    UIAlertView *infoAlert = [[UIAlertView alloc] initWithTitle:title message:message delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
   [infoAlert show];
    
}
@end
