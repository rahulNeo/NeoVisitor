//
//  EventsListTableViewController.h
//  VisitorsData
//
//  Created by Aditya on 10/22/14.
//  Copyright (c) 2014 Neosofttech. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol EventListingDelegate<NSObject>
-(void)selectedEventData:(id)data;
@end
@interface EventsListTableViewController : UITableViewController
@property(weak)id<EventListingDelegate>eventDelegate;
@end
