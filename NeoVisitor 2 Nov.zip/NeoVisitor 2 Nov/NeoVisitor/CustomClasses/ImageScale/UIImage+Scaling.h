//
//  UIImage+Scaling.h
//  DrawingDemo
//
//  Created by Nivrutti on 2/9/15.
//  Copyright (c) 2015 Neosoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Scaling)
- (UIImage*)imageByScalingAndCroppingForSize:(CGSize)targetSize;
-(UIImage *)fixOrientation:(UIImage *)img;

@end
