

#import <Foundation/Foundation.h>

@interface NSString (NULLHandling)

-(NSString *)isNULL;

@end
