
#import "NSString+NULLHandling.h"

@implementation NSString (NULLHandling)

-(NSString *)isNULL
{
    if ((![self isKindOfClass:[NSNull class]]) ||
        ((NSString *)self !=(id)[NSNull null]) ||
        ((NSString *)self!=nil)||
        ([[self stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] length]>0)||
        ([(NSString *)self caseInsensitiveCompare:@"(null)"] != NSOrderedSame) ||
        ([(NSString *)self caseInsensitiveCompare:@"<null>"] != NSOrderedSame))
    {
        return  self;
    }
    return @"";
}
@end