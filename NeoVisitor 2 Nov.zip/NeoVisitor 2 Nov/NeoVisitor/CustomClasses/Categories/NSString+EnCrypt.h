

#import <Foundation/Foundation.h>

@interface NSString (EnCrypt)

-(NSString *)enCryptString;
 @end
