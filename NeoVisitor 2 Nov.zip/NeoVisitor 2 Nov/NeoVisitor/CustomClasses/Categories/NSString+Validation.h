

#import <Foundation/Foundation.h>

@interface NSString (Validation)

-(BOOL)isValid;

@end
