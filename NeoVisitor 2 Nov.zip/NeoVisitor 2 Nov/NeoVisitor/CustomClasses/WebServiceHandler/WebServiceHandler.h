//
//  WebServiceHandler.h
//  NeoVisitor
//
//  Created by webwerks on 2/22/16.
//  Copyright © 2016 webwerks. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebServiceHandler : NSObject

typedef void (^Request_Completion_Block)(id response, NSError * error);
typedef void (^Request_Progress_Block)(NSUInteger numberOfFinishedOperations, NSUInteger totalNumberOfOperations);
typedef void (^Request_Completion_Block_Fetch)();

+ (instancetype)sharedInstance;
-(void)getListingDataFromServerUsingQueue:(Request_Progress_Block)progressBlock Completion:(Request_Completion_Block)completionBlock;
-(void )callPostWSWithMethod:(NSString *)strUrl  Parameters:(NSDictionary *)parameter  Completion:(Request_Completion_Block)completionBlock;
-(void)SyncCardListingDataFromServerUsingQueue:(Request_Completion_Block)completionBlock ArrRequest:(NSMutableArray *)arrReq;

@end
