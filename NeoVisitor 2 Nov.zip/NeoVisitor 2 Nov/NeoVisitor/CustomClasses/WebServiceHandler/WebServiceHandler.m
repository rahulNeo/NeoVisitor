//
//  WebServiceHandler.m
//  NeoVisitor
//
//  Created by webwerks on 2/22/16.
//  Copyright © 2016 webwerks. All rights reserved.
//

#import "WebServiceHandler.h"
#import "Constant.h"
#import "AFNetworking.h"
#import "DBOperations.h"
#import "MBProgressHUD.h"
#import "AppDelegate.h"
@implementation WebServiceHandler
+ (instancetype)sharedInstance
{
    //create single ton instance of webService class
    static id instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    return instance;
}

-(id)getServiceURLString:(NSString *)strServiceParam
{
    return [NSString stringWithFormat:@"%@%@",ServerURL,strServiceParam];
}
-(void)getListingDataFromServerUsingQueue:(Request_Progress_Block)progressBlock Completion:(Request_Completion_Block)completionBlock;
{
    NSMutableArray *arrayOpration=[[NSMutableArray alloc]init];
    
    [arrayOpration addObject:[self prepareRequest:[self getServiceURLString:Get_User_Service] ServiceName:@"GetUser"  Completion:nil]];
    
    [arrayOpration addObject:[self prepareRequest:[self getServiceURLString:Get_EventListing_Service] ServiceName:@"GetEvents" Completion:nil]];
    
    NSArray *operations=[AFURLConnectionOperation batchOfRequestOperations:arrayOpration progressBlock:^(NSUInteger numberOfFinishedOperations, NSUInteger totalNumberOfOperations)
                         {
                             //update progrss block
                             progressBlock(numberOfFinishedOperations,totalNumberOfOperations);
                         } completionBlock:^(NSArray *operations)
                         {
                             //all web servcies are completed ...I am sending block base response
                             completionBlock(nil,nil);
                         }];
    //call Queue
    NSOperationQueue *operationQueue = [[NSOperationQueue alloc] init];
    [operationQueue setSuspended:YES];
    [operationQueue setMaxConcurrentOperationCount:1];
    [operationQueue addOperations:operations waitUntilFinished:NO];
    [operationQueue setSuspended:NO];
}
#pragma mark prepareRequest
-(AFHTTPRequestOperation *)prepareRequest:(NSString *)strUrl ServiceName:(NSString *)strName Completion:(Request_Completion_Block)completionBlock
{
    NSMutableURLRequest *request =[[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:strUrl]cachePolicy:NSURLRequestReloadIgnoringCacheData  timeoutInterval:180.0];
    [request setHTTPMethod:@"GET"];
    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
     {
         if([responseObject isKindOfClass:[NSData class]])
         {
             NSError *parseJsonError;
             id serviceResponse=[NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:&parseJsonError];
             if(!parseJsonError)
             {
                 if([strName isEqualToString:@"GetUser"])
                 {
                     if([serviceResponse isKindOfClass:[NSArray class]])
                     {
                         [DBOperations addUsers:(NSArray *)serviceResponse];
                     }
                     return;
                 }
                 else if ([strName isEqualToString:@"GetEvents"])
                 {
                     if([serviceResponse isKindOfClass:[NSArray class]])
                     {
                         [DBOperations addEvent:(NSArray *)serviceResponse];
                     }
                     return;
                 }
                 if(completionBlock)
                     completionBlock(serviceResponse, nil);
                 return;
             }
         }
     }failure:^(AFHTTPRequestOperation *operation, NSError *error) {
         if(completionBlock)
             completionBlock(nil, error);
     }];
    return operation;
}
-(void )callPostWSWithMethod:(NSString *)strUrl  Parameters:(NSDictionary *)parameter  Completion:(Request_Completion_Block)completionBlock
{
    NSString *encodedUrl = [[self getServiceURLString:strUrl] stringByAddingPercentEscapesUsingEncoding: NSUTF8StringEncoding];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [manager POST:encodedUrl parameters:parameter success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if([responseObject isKindOfClass:[NSData class]])
        {
            NSError *parseJsonError;
            id serviceResponse=[NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:&parseJsonError];
            if(!parseJsonError)
            {
                completionBlock(serviceResponse, nil);
                return;
            }
        }
        NSDictionary *dict=[NSDictionary dictionaryWithObject:@"Error occured while processing request" forKey:@"localizedDescription"];
        NSError *error=[NSError errorWithDomain:@"" code:0 userInfo:dict];
        completionBlock(nil, error);
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        completionBlock(nil, error);
    }];
}

-(void)SyncCardListingDataFromServerUsingQueue:(Request_Completion_Block)completionBlock ArrRequest:(NSMutableArray *)arrReq
{
    NSMutableArray *arrOP=[[NSMutableArray alloc]init];
    for (NSMutableDictionary *dict in arrReq)
    {
        [arrOP addObject:[self getRequestOpration:dict]];
    }
    __block MBProgressHUD *HUD = [[MBProgressHUD alloc] initWithView:[AppDelegate getInstance].window];
    [[AppDelegate getInstance].window addSubview:HUD];
    // Set determinate bar mode
    HUD.mode = MBProgressHUDModeDeterminateHorizontalBar;
    HUD.labelText =[NSString stringWithFormat:@"Upload %ld Card",[arrOP count]];
    [HUD show:YES];
    
    NSArray *operations=[AFURLConnectionOperation batchOfRequestOperations:arrOP progressBlock:^(NSUInteger numberOfFinishedOperations, NSUInteger totalNumberOfOperations)
                         {
                             float percentage=((float) numberOfFinishedOperations / totalNumberOfOperations);
                             HUD.progress=percentage;
                             HUD.labelText=[NSString stringWithFormat:@"%ld in %ld",numberOfFinishedOperations,totalNumberOfOperations];
                         } completionBlock:^(NSArray *operations)
                         {
                             NSLog(@"compaleted");
                             [HUD hide:YES];
                             completionBlock(nil,nil);
                         }];
    //call Queue
    NSOperationQueue *operationQueue = [[NSOperationQueue alloc] init];
    [operationQueue setSuspended:YES];
    [operationQueue setMaxConcurrentOperationCount:3];
    [operationQueue addOperations:operations waitUntilFinished:NO];
    [operationQueue setSuspended:NO];
}
-(AFHTTPRequestOperation *)getRequestOpration:(NSMutableDictionary *)dict
{
    NSNumber *rowId=[dict objectForKey:@"rowID"];
    [dict removeObjectForKey:@"rowID"];
    NSString *strURL=[NSString stringWithFormat:@"%@%@",ServerURL,Sync_Service];
    
    AFHTTPRequestOperation *request = [[AFHTTPRequestOperation alloc] initWithRequest:[[AFHTTPRequestSerializer serializer] requestWithMethod:@"POST" URLString:strURL parameters:dict error: nil]];
    [request setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
     {
         NSError *parseJsonError;
         id serviceResponse=[NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:&parseJsonError];
         NSLog(@"serviceResponse   %@",[serviceResponse objectForKey:@"data"]);
         
         if(!parseJsonError)
         {
             if([[serviceResponse objectForKey:@"data"]isKindOfClass:[NSDictionary class]])
             {
                 NSString *strId=[[serviceResponse objectForKey:@"data"]objectForKey:@"card_id"];
                 [DBOperations updateCardByServerId:rowId entryID:strId];
             }
         }
     }failure:^(AFHTTPRequestOperation *operation, NSError *error)
     {
     }];
    return request;
}

@end
