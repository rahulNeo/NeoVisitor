//
//  CardInfoModel.h
//  NeoVisitor
//
//  Created by webwerks on 2/22/16.
//  Copyright © 2016 webwerks. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CardInfoModel : NSObject

@property (nonatomic,strong)NSNumber *userId;
@property (nonatomic,strong)NSNumber *eventId;
@property (nonatomic,strong)NSNumber *noOfImages;
@property (nonatomic,strong)NSNumber *entryID;
@property (nonatomic,strong)NSNumber *rowID;
@property (nonatomic,strong)NSNumber *behalfUserId;
@property (nonatomic,strong)NSNumber *isSynced;
@property (nonatomic,strong)NSString *visitorPhone;

@property (nonatomic,strong)NSString *rating;
@property (nonatomic,strong)NSString *eventName;
@property (nonatomic,strong)NSString *userEmail;
@property (nonatomic,strong)NSString *visitorEmail;
@property (nonatomic,strong)NSString *name;
@property (nonatomic,strong)NSString *image1Path;
@property (nonatomic,strong)NSString *image2Path;
@property (nonatomic,strong)NSString *eventDate;
@property (nonatomic,strong)NSString *comments;
@property (nonatomic,strong)NSString *createdDate;
@property (nonatomic,strong)NSString *modifiedDate;


//add all property
@end
