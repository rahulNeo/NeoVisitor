//
//  CardInfoModel.m
//  NeoVisitor
//
//  Created by webwerks on 2/22/16.
//  Copyright © 2016 webwerks. All rights reserved.
//

#import "CardInfoModel.h"

@implementation CardInfoModel

@end
