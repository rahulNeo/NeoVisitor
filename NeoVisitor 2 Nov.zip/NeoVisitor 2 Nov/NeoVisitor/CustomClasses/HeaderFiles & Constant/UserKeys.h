//
//  UserKeys.h
//  NeoVisitor
//
//  Created by webwerks on 2/22/16.
//  Copyright © 2016 webwerks. All rights reserved.
//

#ifndef UserKeys_h
#define UserKeys_h
static NSString * const user_id = @"id";
static NSString * const user_email = @"email";
static NSString * const user_password = @"password";


#endif /* UserKeys_h */
