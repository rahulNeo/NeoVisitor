//
//  Constant.h
//  NeoVisitor
//
//  Created by webwerks on 2/22/16.
//  Copyright © 2016 webwerks. All rights reserved.
//

#ifndef Constant_h
#define Constant_h
static NSString * const DB_Name = @"VisitorData";
static NSString * const ServerURL = @"http://neo.showcase-url.com/index.php/sync/";
static NSString * const Sync_Service = @"cards";
static NSString * const Get_EventListing_Service = @"get_events";
static NSString * const Get_User_Service = @"get_users";
static NSString * const Forgot_Password_Service = @"forgot_password";
static NSString * const Reset_Password_Service = @"reset_password";


#define USER_DEFAULTS [NSUserDefaults standardUserDefaults]
#define ON_BEHALF_USERID @"behalfuserid"
#define ON_BEHALF_USEREMAIL @"behalfuseremail"

#define IS_IPHONE4 (fabs((double)[[UIScreen mainScreen]bounds].size.height - (double)480) < DBL_EPSILON)
#define IS_IPHONE5 (fabs((double)[[UIScreen mainScreen]bounds].size.height - (double)568) < DBL_EPSILON)
#define IS_IPHONE6 (fabs((double)[[UIScreen mainScreen]bounds].size.height - (double)667) < DBL_EPSILON)
#define IS_IPHONE6PLUS (fabs((double)[[UIScreen mainScreen]bounds].size.height - (double)736) < DBL_EPSILON)

#endif /* Constant_h */
