//
//  ErrorMessages.h
//  NeoVisitor
//
//  Created by webwerks on 2/22/16.
//  Copyright © 2016 webwerks. All rights reserved.
//

#ifndef ErrorMessages_h
#define ErrorMessages_h

static NSString * const msg_Internet_Connection= @"Please Check internet connection.";
static NSString * const msg_Data_Insert = @"Card has been added successfully";
static NSString * const msg_Data_Updated = @"Card has been added successfully";


static NSString * const msg_Data_Delete = @"Card has been deleted successfully";
static NSString * const msg_Data_Delete_sync = @"Sync Card has been deleted successfully";

static NSString * const msg_Data_Update = @"Card has been updated successfully";
static NSString * const msg_Data_Sync = @"Card has been successfully Sync";
static NSString * const msg_Internet_Error= @"Error occured while posting data";
static NSString * const msg_Data_Insert_error = @"error occured while adding card";
static NSString * const msg_Data_Delete_error = @"error occured while deleting card";
static NSString * const msg_NO_Data = @"No UnSycned Cards Found";


static NSString * const msg_Check_Email= @"Please enter email id";
static NSString * const msg_Check_Password= @"Please enter password";
static NSString * const msg_Wrong_EmailPassword= @"Wrong email and password combination";

static NSString * const msg_check_eventName= @"Please select event name";

static NSString * const msg_vnameOrImage= @"Please provide either visitors name or front image or back image";

static NSString * const msg_invalidEmail= @"Please provide valid email address";



static NSString * const msg_validEname= @"Please select event name";
static NSString * const msg_validComment= @"Please add comment";
static NSString * const msg_validUser= @"Please add visitor name";
static NSString * const msg_validImage= @"Please select image";
static NSString * const msg_rating= @"Rating cannot be empty";
static NSString * const msg_validOnBehalf= @"Please select behalf user name";






///Rating Cannot be empty
//Please provide either visitors name or front image or back image
#endif /* ErrorMessages_h */
