//
//  AppKeys.h
//  NeoVisitor
//
//  Created by webwerks on 2/22/16.
//  Copyright © 2016 webwerks. All rights reserved.
//

#ifndef AppKeys_h
#define AppKeys_h

static NSString * const rem_user_Info = @"loginUserInfo";

static NSString * const rem_remeber = @"rememberMe";

static NSString * const rem_user_id = @"userId";
static NSString * const rem_user_email = @"email";
static NSString * const rem_user_password = @"password";
 
static NSString * const event_eventName = @"eventName";
static NSString * const event_eventID = @"eventId";

#endif /* AppKeys_h */


