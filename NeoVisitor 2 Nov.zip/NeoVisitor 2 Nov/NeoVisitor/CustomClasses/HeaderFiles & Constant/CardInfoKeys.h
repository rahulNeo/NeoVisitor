//
//  CardInfoKeys.h
//  NeoVisitor
//
//  Created by webwerks on 2/22/16.
//  Copyright © 2016 webwerks. All rights reserved.
//

#ifndef CardInfoKeys_h
#define CardInfoKeys_h

static NSString * const card_userId = @"userId";
static NSString * const card_eventId = @"eventId";
static NSString * const card_entryID = @"entryID";
static NSString * const card_eventName = @"eventName";
static NSString * const card_noOfImages = @"noOfImages";
static NSString * const card_rowID = @"rowID";
static NSString * const card_behalfUserId = @"behalfUserId";
static NSString * const card_isSynced = @"isSynced";
static NSString * const card_rating = @"rating";
static NSString * const card_userEmail = @"userEmail";
static NSString * const card_name = @"name";
static NSString * const card_image1Path = @"image1Path";
static NSString * const card_image2Path = @"image2Path";
static NSString * const card_eventDate = @"eventDate";
static NSString * const card_comments = @"comments";
static NSString * const card_createdDate= @"createdDate";
static NSString * const card_modfiedDate = @"modfiedDate";
static NSString * const card_visitorEmail = @"visitorEmail";
static NSString * const card_visitorPhone = @"visitorPhone";
#endif /* CardInfoKeys_h */
