//
//  DBOperations.h
//  NeoVisitor
//
//  Created by webwerks on 2/22/16.
//  Copyright © 2016 webwerks. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDatabase.h"
#import "FMDatabaseQueue.h"
#import "FMResultSet.h"
@class CardInfoModel;
@interface DBOperations : NSObject
typedef void (^DBHandler)(BOOL isInsert);
+(FMDatabaseQueue *)GetDBQueue;
+(void)createSqlTables;
+(void)addUsers:(NSArray *)arrUser;
+(void)addEvent:(NSArray *)arrEvents;
+(void)loadEventAndUsers;
+(void)addCard:(CardInfoModel *)model Block:(DBHandler)handler;
+(void)updateCard:(CardInfoModel *)model Block:(DBHandler)handler;
+(void)updateCardByServerId:(NSNumber *)rowID entryID:(NSString *)strId;
+(BOOL)deleteCard:(NSInteger)flag row:(NSNumber*)rowID event:(NSNumber *)eventID;

+(NSMutableDictionary *)getCardByEventID:(NSNumber *)eventID;
+(NSMutableArray *)getUnSyncCard:(NSNumber *)rowID;
+(NSMutableArray *)getVistorCardByEventID:(NSNumber *)eventID;
+(NSMutableArray *)getVistorCardByEventID:(NSNumber *)eventID RowID:(NSNumber *)rowID;
+(NSNumber *)getTotalUnSyncCard;

@end
