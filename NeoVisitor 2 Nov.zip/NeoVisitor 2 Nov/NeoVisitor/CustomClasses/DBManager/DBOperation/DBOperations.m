
//
//  DBOperations.m
//  NeoVisitor
//
//  Created by webwerks on 2/22/16.
//  Copyright © 2016 webwerks. All rights reserved.
//

#import "DBOperations.h"
#import "AppDelegate.h"
#import "UserKeys.h"
#import "EventKeys.h"
#import "CardInfoModel.h"
#import "AppKeys.h"
#import "Constant.h"
#import "CardInfoKeys.h"
@implementation DBOperations
+(FMDatabaseQueue *)GetDBQueue
{
    return [AppDelegate getInstance].fmDBQueue;
}
#pragma mark createSqlTables
+(void)createSqlTables
{
    FMDatabaseQueue *dbQueue =[self GetDBQueue];
    [dbQueue inTransaction:^(FMDatabase *db, BOOL *rollback) {
        
        //create User Table
        [db executeUpdate:@"CREATE TABLE IF NOT EXISTS Users (userId integer PRIMARY KEY,email varchar,password varchar)"];
        
        //create Event Table
        [db executeUpdate:@"CREATE TABLE IF NOT EXISTS Events (eventId integer PRIMARY KEY,eventName varchar)"];
        
        //create Visitor Info Table
        [db executeUpdate:@"CREATE TABLE IF NOT EXISTS VisitorsInfo (rowID integer NOT NULL PRIMARY KEY AUTOINCREMENT,userId integer,userEmail varchar,visitorEmail varchar,visitorPhone varchar,name varchar,eventName varchar,eventId integer,image1Path varchar,image2Path varchar,eventDate varchar,comments varchar,isSynced integer,entryID integer,rating varchar,behalfUserId integer,createdDate varchar,modifiedDate varchar,noOfImages integer);"];
      
    }];
}
#pragma mark validateText
+(id)validateText:(id)text
{
    if([text isKindOfClass:[NSString class]])
    {
        return text!=nil?text:NULL;
    }
    return  NULL;
}
#pragma mark validateNumber
+(NSNumber *)validateNumber:(id)text
{
    if([text isKindOfClass:[NSNumber class]])
    {
        return text;
    }
    return  [NSNumber numberWithInt:0];
}
+(void)addUsers:(NSArray *)arrUser
{
    FMDatabaseQueue *queueObj=[self GetDBQueue];
    [queueObj inTransaction:^(FMDatabase *db, BOOL *rollback)
     {
         [db executeUpdate:@"Delete from Users"];
         for (NSDictionary *dict in arrUser)
         {
             @autoreleasepool {
                 NSString *_user_id=[self validateText:[dict objectForKey:user_id]];
                 NSString *_email=[self validateText:[dict objectForKey:user_email]];
                 NSString *_password=[self validateText:[dict objectForKey:user_password]];
                 [db executeUpdate:@"INSERT OR REPLACE INTO Users (userId,email,password) values (?,?,?)",_user_id,_email,_password];
             }
         }
     }];
}

+(void)addEvent:(NSArray *)arrEvents
{
    FMDatabaseQueue *queueObj=[self GetDBQueue];
    [queueObj inTransaction:^(FMDatabase *db, BOOL *rollback)
     {
         [db executeUpdate:@"Delete from Events"];
         for (NSDictionary *dict in arrEvents)
         {
             @autoreleasepool {
                 
                 NSNumber *_event_id=[self validateText:[dict objectForKey:@"id"]];
                 NSString *_eventName=[self validateText:[dict objectForKey:@"name"]];
                 [db executeUpdate:@"INSERT OR REPLACE INTO Events (eventId,eventName) values (?,?)",_event_id,_eventName];
             }
         }
     }];
}
+(void)loadEventAndUsers
{
    if(![AppDelegate getInstance].arrAppEvents)
    {
        [AppDelegate getInstance].arrAppEvents=[[NSMutableArray alloc]init];
    }
    if(![AppDelegate getInstance].arrAppUsers)
    {
        [AppDelegate getInstance].arrAppUsers=[[NSMutableArray alloc]init];
    }
    
    FMDatabaseQueue *queueObj=[self GetDBQueue];
    [queueObj  inDatabase:^(FMDatabase *db) {
        
        //get all events
        FMResultSet *fmResultSetObj1;
        fmResultSetObj1=[db executeQuery:@"select * from Events order by eventId desc"];
        while ([fmResultSetObj1 next])
        {
            [[AppDelegate getInstance].arrAppEvents addObject:fmResultSetObj1.resultDictionary];
        }
        [fmResultSetObj1 close];
        
        //get all users
        FMResultSet *fmResultSetObj2;
        fmResultSetObj2=[db executeQuery:@"SELECT * FROM Users ORDER BY email"];
        while ([fmResultSetObj2 next])
        {
            [[AppDelegate getInstance].arrAppUsers addObject:fmResultSetObj2.resultDictionary];
        }
        [fmResultSetObj2 close];
    }];
    
}

+(void)addCard:(CardInfoModel *)model Block:(DBHandler)handler
{
    FMDatabaseQueue *queueObj=[self GetDBQueue];
    [queueObj inTransaction:^(FMDatabase *db, BOOL *rollback)
     {
         BOOL success= [db executeUpdate:@"INSERT INTO VisitorsInfo (userId,userEmail,visitorEmail,visitorPhone,name,eventName,eventId,image1Path,image2Path,eventDate,comments,isSynced,entryID,rating,behalfUserId,createdDate,modifiedDate,noOfImages) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",model.userId,model.userEmail,model.visitorEmail,model.visitorPhone,model.name,model.eventName,model.eventId,model.image1Path,model.image2Path,model.eventDate,model.comments,model.isSynced,model.entryID,model.rating,model.behalfUserId,model.createdDate,model.modifiedDate,model.noOfImages];
         handler(success);
     }];
}
+(void)updateCard:(CardInfoModel *)model Block:(DBHandler)handler
{
    FMDatabaseQueue *queueObj=[self GetDBQueue];
    [queueObj inTransaction:^(FMDatabase *db, BOOL *rollback)
     {
         BOOL success= [db executeUpdate:@"UPDATE VisitorsInfo SET visitorEmail =?,visitorPhone =?,name =?,image1Path=?,image2Path =?,comments =?,isSynced =?,rating =?,modifiedDate =?,noOfImages =?  WHERE rowID=?",model.visitorEmail,model.visitorPhone,model.name,model.image1Path,model.image2Path,model.comments,model.isSynced,model.rating,model.modifiedDate,model.noOfImages,model.rowID];
         handler(success);
     }];
}

+(BOOL)deleteCard:(NSInteger)flag row:(NSNumber*)rowID event:(NSNumber *)eventID
{
    __block BOOL isDeleted=NO;
    FMDatabaseQueue *queueObj=[self GetDBQueue];
    [queueObj inTransaction:^(FMDatabase *db, BOOL *rollback)
     {
         if(flag==0)
         {
             isDeleted=[db executeUpdate:@"delete from VisitorsInfo Where rowID=?",rowID];
         }
         else if(flag==1)
         {
             isDeleted=[db executeUpdate:@"delete from VisitorsInfo Where userId=? and eventId=? and isSynced=1",[NSNumber numberWithInteger:[[[USER_DEFAULTS objectForKey:rem_user_Info]objectForKey:rem_user_id]integerValue]],eventID];
         }
         else
         {
             isDeleted=[db executeUpdate:@"delete from VisitorsInfo Where userId=? and eventId=?",[NSNumber numberWithInteger:[[[USER_DEFAULTS objectForKey:rem_user_Info]objectForKey:rem_user_id]integerValue]],eventID];
         }
     }];
    
    return isDeleted;
}
+(NSMutableArray *)getVistorCardByEventID:(NSNumber *)eventID
{
    NSMutableArray  *arrCard=[[NSMutableArray alloc]init];
    FMDatabaseQueue *queueObj=[self GetDBQueue];
    [queueObj  inDatabase:^(FMDatabase *db) {
        
        FMResultSet *fmResultSetObj;
        fmResultSetObj=[db executeQuery:@"select * from VisitorsInfo Where userId=? and eventId=?",[NSNumber numberWithInteger:[[[USER_DEFAULTS objectForKey:rem_user_Info]objectForKey:rem_user_id]integerValue]],eventID];
        while  ([fmResultSetObj next])
        {
            [arrCard addObject:fmResultSetObj.resultDictionary];
        }
        [fmResultSetObj close];
    }];
    return arrCard;
}
+(NSMutableArray *)getVistorCardByEventID:(NSNumber *)eventID RowID:(NSNumber *)rowID
{
    NSMutableArray  *arrCard=[[NSMutableArray alloc]init];
    FMDatabaseQueue *queueObj=[self GetDBQueue];
    [queueObj  inDatabase:^(FMDatabase *db) {
        
        FMResultSet *fmResultSetObj;
        fmResultSetObj=[db executeQuery:@"select * from VisitorsInfo Where userId=? and eventId=? and  rowID=?",[NSNumber numberWithInteger:[[[USER_DEFAULTS objectForKey:rem_user_Info]objectForKey:rem_user_id]integerValue]],eventID,rowID];
        while  ([fmResultSetObj next])
        {
            [arrCard addObject:fmResultSetObj.resultDictionary];
        }
        [fmResultSetObj close];
    }];
    return arrCard;
}
+(NSMutableDictionary *)getCardByEventID:(NSNumber *)eventID
{
    NSMutableDictionary  *dict=[[NSMutableDictionary alloc]init];
    FMDatabaseQueue *queueObj=[self GetDBQueue];
    [queueObj  inDatabase:^(FMDatabase *db) {
        
        //get all events
        FMResultSet *fmResultSetObj;
        fmResultSetObj=[db executeQuery:@"select count(*) from VisitorsInfo Where userId=? and eventId=? and isSynced=1",[NSNumber numberWithInteger:[[[USER_DEFAULTS objectForKey:rem_user_Info]objectForKey:rem_user_id]integerValue]],eventID];
        NSNumber *sync=[NSNumber numberWithInteger:0];
        if ([fmResultSetObj next])
        {
            sync=[NSNumber numberWithInteger:[fmResultSetObj intForColumnIndex:0]] ;
        }
        [fmResultSetObj close];
        [dict setObject:sync forKey:@"Sync"];
        
        
        FMResultSet *fmResultSetObj1;
        fmResultSetObj1=[db executeQuery:@"select count(*) from VisitorsInfo Where userId=? and eventId=?",[NSNumber numberWithInteger:[[[USER_DEFAULTS objectForKey:rem_user_Info]objectForKey:rem_user_id]integerValue]],eventID];
        NSNumber *total=[NSNumber numberWithInteger:0];
        if ([fmResultSetObj1 next])
        {
            total=[NSNumber numberWithInteger:[fmResultSetObj1 intForColumnIndex:0]] ;
        }
        [fmResultSetObj1 close];
        [dict setObject:total forKey:@"Total"];
    }];
    return dict;
}
+(NSNumber *)getTotalUnSyncCard
{
    __block NSNumber *unSyncCard=[NSNumber numberWithInteger:0];
    FMDatabaseQueue *queueObj=[self GetDBQueue];
    [queueObj  inDatabase:^(FMDatabase *db)
     {
         FMResultSet *fmResultSetObj;
         fmResultSetObj=[db executeQuery:@"select count(*) from VisitorsInfo Where userId=? and isSynced=0",[NSNumber numberWithInteger:[[[USER_DEFAULTS objectForKey:rem_user_Info]objectForKey:rem_user_id]integerValue]]];
         if ([fmResultSetObj next])
         {
             unSyncCard=[NSNumber numberWithInteger:[fmResultSetObj intForColumnIndex:0]] ;
         }
         [fmResultSetObj close];
     }];
    return  unSyncCard;
}

+(NSMutableArray *)getUnSyncCard:(NSNumber *)rowID
{
    NSMutableArray  *arrCard=[[NSMutableArray alloc]init];
    FMDatabaseQueue *queueObj=[self GetDBQueue];
    
    [queueObj  inDatabase:^(FMDatabase *db)
     {
         FMResultSet *fmResultSetObj;
         if(rowID)
         {
             fmResultSetObj=[db executeQuery:@"select * from VisitorsInfo Where userId=? and rowID=? and isSynced=0",[NSNumber numberWithInteger:[[[USER_DEFAULTS objectForKey:rem_user_Info]objectForKey:rem_user_id]integerValue]],rowID];
             
         }
         else
         {
             fmResultSetObj=[db executeQuery:@"select * from VisitorsInfo Where userId=? and isSynced=0",[NSNumber numberWithInteger:[[[USER_DEFAULTS objectForKey:rem_user_Info]objectForKey:rem_user_id]integerValue]]];
             
         }
         while  ([fmResultSetObj next])
         {
             NSDictionary *dbData=fmResultSetObj.resultDictionary;
             NSMutableDictionary *cardDict=[[NSMutableDictionary alloc]init];
             NSNumber *rowID=[dbData objectForKey:card_rowID];
             NSNumber *userId=[dbData objectForKey:card_userId];
             NSString *userEmail=[self compareNUll:[dbData objectForKey:card_userEmail]];
             NSString *name=[self compareNUll:[dbData objectForKey:card_name]];
             NSNumber *eventId=[dbData objectForKey:card_eventId];
             NSString *image1Path=[self compareNUll:[dbData objectForKey:card_image1Path]];
             NSString *image2Path=[self compareNUll:[dbData objectForKey:card_image2Path]];
             NSString *comments=[self compareNUll:[dbData objectForKey:card_comments]];
             
             NSNumber *entryID=[dbData objectForKey:card_entryID];
             NSNumber *rating=[NSNumber numberWithInteger:[[dbData objectForKey:card_rating]integerValue]];
             NSNumber *behalfUserId=[dbData objectForKey:card_behalfUserId];
             
             
             NSString *strTargetEmail=[self compareNUll:[dbData objectForKey:card_visitorEmail]];
             NSString *targetPhoneNumber=[self compareNUll:[dbData objectForKey:card_visitorPhone]];

             
             if([behalfUserId integerValue]==[userId integerValue])
             {
                 [cardDict setObject:userId forKey:@"user_id"];
                 [cardDict setObject:behalfUserId forKey:@"behalfUserId"];
             }
             else
             {
                 [cardDict setObject:behalfUserId forKey:@"user_id"];
                 [cardDict setObject:userId forKey:@"behalfUserId"];
             }
             
             [cardDict setObject:userEmail forKey:@"email_id"];
             [cardDict setObject:name forKey:@"name"];
             [cardDict setObject:eventId forKey:@"event_id"];
             [cardDict setObject:comments forKey:@"comments"];
             [cardDict setObject:entryID forKey:@"card_id"];
             [cardDict setObject:rating forKey:@"rating"];
             [cardDict setObject:rowID forKey:@"rowID"];
             [cardDict setObject:strTargetEmail forKey:@"targetEmailAddress"];
             [cardDict setObject:targetPhoneNumber forKey:@"targetPhoneNumber"];
             
             NSData *data=[NSData dataWithContentsOfFile:[self checkImages:image1Path UserID:[userId stringValue]]];
             if([data length]>0)
             {
                 [cardDict setObject:[self encodeToBase64StringNew:data] forKey:@"photo1"];
             }
             else
             {
                 [cardDict setObject:@"" forKey:@"photo1"];
             }
             NSData *data1=[NSData dataWithContentsOfFile:[self checkImages:image2Path UserID:[userId stringValue]]];
             if([data1 length]>0)
             {
                 [cardDict setObject:[self encodeToBase64StringNew:data1] forKey:@"photo2"];
             }
             else
             {
                 [cardDict setObject:@"" forKey:@"photo2"];
             }
             
             [arrCard addObject:cardDict];
         }
         [fmResultSetObj close];
     }];
    return arrCard;
}
+(void)updateCardByServerId:(NSNumber *)rowID entryID:(NSString *)strId
{
    FMDatabaseQueue *queueObj=[self GetDBQueue];
    [queueObj inTransaction:^(FMDatabase *db, BOOL *rollback)
     {
         if(strId!=nil)
         {
             [db executeUpdate:@"UPDATE VisitorsInfo SET isSynced=1 , entryID=? WHERE rowID=?",[NSNumber numberWithInteger:[strId integerValue]],rowID];
         }
         else
         {
             [db executeUpdate:@"UPDATE VisitorsInfo SET isSynced=1 WHERE rowID=?",rowID];
         }
     }];
}
+(NSString *)compareNUll:(id)val
{
    if([val isKindOfClass:[NSString class]])
    {
        if ((![val isKindOfClass:[NSNull class]]) ||
            ((NSString *)val !=(id)[NSNull null]) ||
            ((NSString *)val!=nil)||
            ([[val stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] length]>0)||
            ([(NSString *)val caseInsensitiveCompare:@"(null)"] != NSOrderedSame) ||
            ([(NSString *)val caseInsensitiveCompare:@"<null>"] != NSOrderedSame))
        {
            return  val;
        }
    }
    return @"";
}
+ (NSString *)encodeToBase64StringNew:(NSData *)data
{
    return [data base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
}
+(NSString *)checkImages:(NSString *)fileName UserID:(NSString *)userId
{
    NSString *path=[[AppDelegate getInstance]filePathWithFolder:fileName folder:userId];
    return path;
}
@end
