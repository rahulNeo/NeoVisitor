//
//  CommonMethods.m
//  NeoVisitor
//
//  Created by webwerks on 2/22/16.
//  Copyright © 2016 webwerks. All rights reserved.
//

#import "CommonMethods.h"

@implementation CommonMethods
#pragma mark getFileName

+(NSString *)getFileName
{
    NSString *strFileName=[NSString stringWithFormat:@"%f",[[NSDate date] timeIntervalSince1970]];
    strFileName=[strFileName stringByReplacingOccurrencesOfString:@"." withString:@""];
    NSString *strRandom=[self randomStringWithLength:5];
    
    return [NSString stringWithFormat:@"%@%@",strFileName,strRandom];
}
NSString *letters = @"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
+(NSString *) randomStringWithLength: (int) len {
    
    NSMutableString *randomString = [NSMutableString stringWithCapacity: len];
    
    for (int i=0; i<len; i++) {
        [randomString appendFormat: @"%C", [letters characterAtIndex: arc4random_uniform((int)[letters length])]];
    }
    return randomString;
}

+(BOOL) checkEmptyString :(id ) str
{
    if([str isKindOfClass:[NSString class]])
    {
        if([str length] >0 && ![str isEqualToString:@""] && ![str isEqualToString:@"<null>"] && ![str isEqualToString:@"(null)"] && ![str isKindOfClass:[NSNull class]])
        {
            return false;
        }
        else
            return true;
    }
    
    return true;
}

+(BOOL)validateEmail:(NSString*)string
{
    NSString *trimmedString = [string stringByTrimmingCharactersInSet:
                               [NSCharacterSet whitespaceCharacterSet]];
    
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:trimmedString];
}


@end
