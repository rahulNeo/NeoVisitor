//
//  CommonMethods.h
//  NeoVisitor
//
//  Created by webwerks on 2/22/16.
//  Copyright © 2016 webwerks. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CommonMethods : NSObject
+(NSString *)getFileName;
+(BOOL) checkEmptyString :(id ) str;
+(BOOL)validateEmail:(NSString*)string;

@end
