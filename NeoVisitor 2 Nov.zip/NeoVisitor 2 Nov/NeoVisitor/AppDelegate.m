//
//  AppDelegate.m
//  NeoVisitor
//
//  Created by webwerks on 22/02/16.
//  Copyright © 2016 webwerks. All rights reserved.
//

#import "AppDelegate.h"
#import "Reachability.h"
#import "Constant.h"
#import "DBOperations.h"
#import "CommonMethods.h"
#import "NSString+EnCrypt.h"
@interface AppDelegate ()
@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    [self DatebaseInit:DB_Name];
    NSString *strDb=[NSString stringWithFormat:@"%@.sqlite",DB_Name];
    NSString *strDBQueue=[self dbPath:strDb];
    NSLog(@"%@",strDBQueue);
    self.fmDBQueue =[FMDatabaseQueue databaseQueueWithPath:strDBQueue];
    [DBOperations    createSqlTables];
    // Override point for customization after application launch.
    [[UINavigationBar appearance] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor], NSForegroundColorAttributeName, nil]];
    
    return YES;
}
#pragma mark PlayProgressHudAsPerType
-(void)PlayProgressHudAsPerType:(NSString *)text View:(UIView*)inputView
{
    if(!inputView)
    {
        inputView=self.window.rootViewController.view;
    }
    if(!hudObj)
    {
        hudObj = [[MBProgressHUD alloc] initWithView:inputView];
        hudObj.userInteractionEnabled=NO;
    }
    [inputView addSubview:hudObj];
    [inputView bringSubviewToFront:hudObj];
    // Configure for text only and offset down
    hudObj.mode = MBProgressHUDModeText;
    hudObj.detailsLabelText = text;
    hudObj.margin = 13.f;
    hudObj.yOffset = 0.0f;
    hudObj.removeFromSuperViewOnHide = YES;
    UINavigationController *controller=(UINavigationController *)self.window.rootViewController;
    hudObj.color=controller.navigationBar.barTintColor;
    [hudObj show:YES];
    [hudObj hide:YES afterDelay:2.0];
}
-(void)showHud:(UIView*)inputView Title:(NSString *)strTitle
{
    if(hud)
    {
        [hud removeFromSuperview];
        hud=nil;
    }
    if(!inputView)
    {
        inputView=self.window.rootViewController.view;
    }
    if(!hud)
    {
        hud = [[MBProgressHUD alloc] initWithView:inputView];
    }
    [inputView addSubview:hud];
    [inputView bringSubviewToFront:hud];
    hud.labelText = strTitle;
    [hud show:YES];
}
-(void)closeHud
{
    [hud closeHud];
}

+(void)showAlert:(NSString *)title withStatus:(NSString *)message
{
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:title
                          message:message
                          delegate:nil
                          cancelButtonTitle:nil
                          otherButtonTitles:@"OK", nil];
    
    [alert show];
    alert=nil;
}
-(void)DatebaseInit:(NSString *)strDbName
{
    NSString *strDb=[NSString stringWithFormat:@"%@.sqlite",strDbName];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSString *strPath=[self dbPath:strDb];
    NSError *error;
    BOOL success = [fileManager fileExistsAtPath:strPath];
    if(!success)
    {
        NSString  *bundlePath = [[NSBundle mainBundle] pathForResource:strDbName ofType:@"sqlite"];
        success = [fileManager copyItemAtPath:bundlePath toPath:strPath error:&error];
        if (!success)
            NSAssert1(0, @"Failed to create writable database file with message '%@'.", [error localizedDescription]);
    }
}
-(NSString *)dbPath:(NSString *)fileName
{
    NSString *dbDocumentsPath =@"";
    if(![CommonMethods checkEmptyString:fileName])
    {
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDir = [paths objectAtIndex:0];
        dbDocumentsPath=[documentsDir stringByAppendingPathComponent:fileName];
    }
    return dbDocumentsPath;
}
-(NSString *)filePathWithFolder:(NSString *)fileName folder:(NSString *)strFolderName
{
    NSString *dbDocumentsPath =@"";
    if(![CommonMethods checkEmptyString:fileName])
    {
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        NSString *dataPath = [documentsDirectory stringByAppendingPathComponent:strFolderName];
        
        if (![[NSFileManager defaultManager] fileExistsAtPath:dataPath])
        {
            [[NSFileManager defaultManager] createDirectoryAtPath:dataPath withIntermediateDirectories:NO attributes:nil error:nil];
        }
        dbDocumentsPath=[dataPath stringByAppendingPathComponent:fileName];
    }
       return dbDocumentsPath;
}
-(void)deleteFileFromfolder:(NSString *)fileName folder:(NSString *)strFolderName
{
    if(![CommonMethods checkEmptyString:fileName])
    {
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        NSString *dataPath = [documentsDirectory stringByAppendingPathComponent:strFolderName];
        NSString *dbDocumentsPath=[dataPath stringByAppendingPathComponent:fileName];
        if ([[NSFileManager defaultManager]fileExistsAtPath:dbDocumentsPath])
        {
            [[NSFileManager defaultManager]removeItemAtPath:dbDocumentsPath error:NULL];
        }
    }
}
+(AppDelegate *)getInstance
{
    return  (AppDelegate *)[UIApplication sharedApplication].delegate;
}
#pragma mark Internet Connection
-(BOOL)CheckNetWorkConnection
{
    BOOL check=NO;
    Reachability *Reach = [Reachability reachabilityForInternetConnection];
    [Reach startNotifier];
    NetworkStatus netStatus = [Reach currentReachabilityStatus];
    if(netStatus == NotReachable)
    {
        check=NO;
    }
    else
    {
        check=YES;
    }
    return check;
}

+(NSNumber *)getUserID 
{
    
    return nil;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
