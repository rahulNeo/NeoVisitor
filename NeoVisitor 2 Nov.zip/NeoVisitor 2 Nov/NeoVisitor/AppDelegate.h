//
//  AppDelegate.h
//  NeoVisitor
//
//  Created by webwerks on 22/02/16.
//  Copyright © 2016 webwerks. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"
#import "FMDatabaseQueue.h"
@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    MBProgressHUD *hud,*hudObj;
}
@property (strong,nonatomic) UIWindow *window;
@property (nonatomic,strong) FMDatabaseQueue *fmDBQueue;
@property (nonatomic,strong) NSMutableArray *arrAppUsers;
@property (nonatomic,strong) NSMutableArray *arrAppEvents;

-(void)PlayProgressHudAsPerType:(NSString *)text View:(UIView*)inputView;
-(void)showHud:(UIView*)inputView Title:(NSString *)strTitle;
-(void)closeHud;
-(BOOL)CheckNetWorkConnection;
-(NSString *)dbPath:(NSString *)fileName;
-(NSString *)filePathWithFolder:(NSString *)fileName folder:(NSString *)strFolderName;
+(AppDelegate *)getInstance;
+(void)showAlert:(NSString *)title withStatus:(NSString *)message;
-(void)deleteFileFromfolder:(NSString *)fileName folder:(NSString *)strFolderName;

@end

